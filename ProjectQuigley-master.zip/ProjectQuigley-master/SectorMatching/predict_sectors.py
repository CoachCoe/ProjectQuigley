from joblib import load
import numpy as np
from pymongo import MongoClient
import pandas as pd
#CEDC_Quigley
# lpP9pCcDxQ2Y0tv8

client = MongoClient('mongodb+srv://ridgebaseaq-docdb-dqrxk.mongodb.net/test'
                        ,username="CEDC_Quigley"
                        ,password="lpP9pCcDxQ2Y0tv8"
                        ,authSource='admin'
                        ,authMechanism='SCRAM-SHA-1')

database = client['legislative_documents']
collection = database['legiscan_bill_metadata']

def fetch_possible_sectors(bill_ids, clf, n=3):
    """
    Fetch the top `n` sectors for each bill given, using `clf`. `bill_ids` is a list
    of Bill IDs as integers.

    Returns a list of dictionaries of the form:
    {"bill_id": int, "sector_id": int, "probability": float}
    """
    
    bill_desc = []
    bill_title = []
    bill_ids = all_data.bill_id

    for bill_id in bill_ids:
        bill = collection.find_one({'bill_id': bill_id})
        
        bill_title.append(str(bill['title']))
        bill_desc.append(str(bill['description']))

    X = pd.DataFrame(data={"bill_title": bill_title, "bill_description": bill_desc})
    probs = clf.predict_proba(X)
    best_n = np.argsort(probs, axis=1)[:,-n:]
    all_bills = []

    for bill_index, best_n in enumerate(best_n):
        possibilities = []
        for index in best_n:
            possibilities.append({
                "bill_id": bill_ids[bill_index],
                "sector_id": clf.classes_[index],
                "probability": probs[bill_index][index]
            })
        all_bills.append(possibilities)

    return all_bills

# this is the classifier from the training script, so you
# can import that function or load the saved classifier.
clf = load("sector_classifier_CA2019.joblib")

# load data, all you need is the bill ids to predict.
all_data = pd.read_csv("18Oct2020Predictions.csv")
bill_ids = all_data.bill_id

# fetch assignments for each bill id given. Returns a list
# of lists of dictionaries, as described in the function.
assignments = fetch_possible_sectors(bill_ids, clf, n=3)


# The below code is to load in the sector information beyond
# just the subsector id, if needed.

# CSV file of the form: 
# sector_id, sector_name, subsector_id, subsector_name
sector_df = pd.read_csv("sector_keywords.csv", index_col="subsector_id")

# merge sector information into the dataframe all_data above.
sectors = [
    [], [], []
]
for bill_sectors in assignments:
    bill_id = bill_sectors[0]["bill_id"]

    for ind, sector_assignment in enumerate(bill_sectors):
        prob = sector_assignment["probability"]

        sector_id = sector_assignment['sector_id']
        sector = sector_df.loc[sector_id]
        sectors[ind].append(f"{sector_id}. {sector.at['sector_name']} - {sector.at['subsector_name']} ({prob:.1%})")

all_data['sector_affected_1'] = sectors[2]
all_data['sector_affected_2'] = sectors[1]
all_data['sector_affected_3'] = sectors[0]

#all_data.sector_affected_1 = sectors[2]
#all_data.sector_affected_2 = sectors[1]
#all_data.sector_affected_3 = sectors[0]

# save CSV with sector columns filled in.
all_data.to_csv("18Oct2020PredictionsSectors.csv")