import pandas as pd
from sklearn.model_selection import GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.model_selection import train_test_split

# SET UP A TRANSFORMER AND PIPELINE TO PREPROCESS DATA
transformer = ColumnTransformer([
    ('bill_title_tfidf', TfidfVectorizer(), 'bill_title'),
    ('bill_description_tfidf', TfidfVectorizer(), 'bill_description')
])

classifier = SGDClassifier(loss='hinge', penalty='l2', alpha=0.001)

pipe = Pipeline([
    ("tfidf", transformer),
    ("clf", classifier)
])

def train_classifier(X_train, y_train, X_test=None, y_test=None, label="Classifier"):
    """
    Train a new classifier using GridSearchCV on the provided training data.

    If testing data is provided, a score will be printed using the label argument
    to differentiate when debugging.

    Returns: A trained SKLearn Classifier
    """
    # these parameters are used with grid search to tune
    parameters = {
        'clf__alpha': (0.0001, 0.001, 0.005, 0.01, 0.1),
        'clf__loss': ('log', 'modified_huber', 'perceptron'),
        'clf__max_iter': (1000, 10000)
    }

    grid_search = GridSearchCV(pipe, parameters, cv=5)
    grid_search.fit(X_train, y_train)

    if X_test is not None and y_test is not None:
        print(label, "Score:", grid_search.score(X_test, y_test))
    
    return grid_search


# LOAD IN CSV DATA: bill_id, bill_title, bill_description, subsector_id
# https://docs.google.com/spreadsheets/d/15UrcOVHclR0wjc3xk9UVMpofjhk0zyj2mEN_wZoB0Ew/edit?ts=5f3d6e0a#gid=0
training = pd.read_csv("train.csv")

# USE THIS FOR DATA THAT IS ENTIRELY TRAINING
X_train = training.loc[:, ["bill_title", "bill_description"]]
y_train = training.subsector_id

# USE THIS IF YOU WANT TO SEE PERFORMANCE OF THE TRAINED CLASSIFIER
# X_all = training.loc[:, ["bill_title", "bill_description"]]
# y_all = training.subsector_id
# X_train, X_test, y_train, y_test = train_test_split(X_all, y_all)

# TRAIN THE CLASSIFIER USING THE ABOVE DATA
# NOTE: all kwargs are optional. Uncomment end of line if you want
# to see performance of the trained classifier.
clf = train_classifier(X_train, y_train) #, X_test=X_test, y_test=y_test, label="California Classifier")

# THIS CLASSIFIER CAN BE SAVED FOR PREDICTIONS:
from joblib import dump
dump(clf, 'sector_classifier_CA2019.joblib')