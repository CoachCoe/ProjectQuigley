# tutorial/01-create-workspace.py
from azureml.core import Workspace

ws = Workspace.create(name='azure_ml_learning', # provide a name for your workspace
                      subscription_id='8d8bcbfe-86b4-42bb-a470-a8cf97c98d69', # provide your subscription ID
                      resource_group='project-quigley', # provide a resource group name
                      create_resource_group=True,
                      location='eastus2') # For example: 'westeurope' or 'eastus2' or 'westus2' or 'southeastasia'.

# write out the workspace details to a configuration file: .azureml/config.json
ws.write_config(path='./azureml')