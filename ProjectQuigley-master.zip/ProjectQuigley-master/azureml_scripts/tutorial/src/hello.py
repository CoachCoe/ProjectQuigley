# src/hello.py
print("Hello world!")