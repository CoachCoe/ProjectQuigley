import sys
import pickle
from sklearn import preprocessing
from os import path
import pandas as pd
from pymongo import MongoClient

mongo_username= 'CEDC_Quigley'
mongo_password= 'lpP9pCcDxQ2Y0tv8'
mongo_server = 'mongodb+srv://ridgebaseaq-docdb-dqrxk.mongodb.net/test'
mongo_authSource = 'admin'
mongo_authMechanism = 'SCRAM-SHA-1'
mongo_database = 'legislative_documents'
mongo_people_collection = 'legiscan_people_data'
mongo_billmeta_collection = 'legiscan_bill_metadata'
mongo_vote_collection = 'legiscan_vote_data'


client = MongoClient(mongo_server
                        ,username=mongo_username
                        ,password=mongo_password
                        ,authSource=mongo_authSource
                        ,authMechanism=mongo_authMechanism)

#**********************************************************************************************************************************

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

#the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('running', state_gov_nm, year_to_process, state_id)

#define file names for the inpout and output
_raw_bill_metadata = path.join(data_file_location,  state_gov_nm + year_to_process + 'raw_bill_metadata.list')
_LegPeopleData_CSV = path.join(data_file_location, state_gov_nm + year_to_process + 'LegPeopleData.csv')
_SessionBodyVector = path.join(data_file_location, state_gov_nm + year_to_process + 'SessionBodyVector.dict')

#This section will grab all of the sponsors for each bill which will be turned into a one hote encoding during feature layer creation
#---------------------------------------------------
#load the raw bill metadata
with open(_raw_bill_metadata,'rb') as f:
    bill_data = pickle.load(f)

bill_list = []
sponsor_list = []

#Loop trhough and create a string for all the sponsors
for b in bill_data:
    
    #bill_list.append(b['bill_id'])
    sponsor_temp = ''
    for s in b['sponsors']:
        bill_list.append(b['bill_id'])
        sponsor_list.append(str(s['name']).replace(' ','_').replace("'","").replace(",","").lower())
#        sponsor_temp = sponsor_temp + '|' + s['name']
#    sponsor_list.append(sponsor_temp[:-1])

sponsor_dict = {
'bill_id'   : bill_list
,'sponsors' : sponsor_list
}

LegSponsorDF = pd.DataFrame(sponsor_dict)

print(LegSponsorDF.head(),LegSponsorDF.shape)

LegSponsorDF.to_csv(_LegPeopleData_CSV)


#This will get the legislative body's party lean by year to be paired with the sponsorship lean
chamber = ["H", "S"]

#Collect the roll calls by year
roll_call_by_year = []

database = client[mongo_database]
collection = database[mongo_billmeta_collection]

for l in collection.find({"$and": [{'state': state_gov_nm}, {'session.year_end': {'$eq': int(year_to_process)}}]}):
    for v in l['votes']:
        roll_call_by_year.append(v['roll_call_id'])

print(len(roll_call_by_year))

politicians = {'people_id':[],'chamber':[]}

database = client[mongo_database]
collections = database[mongo_vote_collection]

for i in collections.find({'roll_call_id': {'$in':  roll_call_by_year}}):
    for j in i['votes']:
        person = j['people_id']
        if person in politicians['people_id']:
            continue
        else:
            politicians['people_id'].append(j['people_id'])
            if i['chamber'] in ['H','A']:
                politicians['chamber'].append('Rep')
            elif i['chamber'] in ['S']:
                politicians['chamber'].append('Sen')
            else:
                politicians['chamber'].append('')

house_session_vec = 0
senate_session_vec = 0
session_vec_count = 0
total_count = 0

collections = database[mongo_people_collection]

#house vector
for i in collections.find({"$and": [{'people_id':{'$in':politicians['people_id']},'role':{'$in':['Rep']}}]}):
    if i['party'] == 'R':
        session_vec_count += 1
    elif i['party'] == 'D':
        session_vec_count += -1
    total_count += 1

house_session_vec = session_vec_count/total_count

print('House Count:', total_count, 'House Vec Count:', session_vec_count, 'House Vec:', house_session_vec)

total_count = 0
session_vec_count = 0
#senate vector
for i in collections.find({"$and": [{'people_id':{'$in':politicians['people_id']},'role':'Sen'}]}):
    if i['party'] == 'R':
        session_vec_count += 1
    elif i['party'] == 'D':
        session_vec_count += -1
    total_count += 1

senate_session_vec = session_vec_count/total_count

print('Senate Count:', total_count, 'Senate Vec Count:', session_vec_count, 'Senate Vec:', senate_session_vec)

session_body_vecs = {'year':[year_to_process, year_to_process], 'chamber':['H', 'S'],'partisan_vector':[house_session_vec, senate_session_vec]}

with open(_SessionBodyVector,'wb') as f:
    pickle.dump(session_body_vecs, f)

