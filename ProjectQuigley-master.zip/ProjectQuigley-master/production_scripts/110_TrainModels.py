import pickle
import numpy as np
import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import SGDClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report
from os import path
from pprint import pprint
from time import time
import logging
import sys

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

#the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('Running', state_gov_nm, year_to_process)

_LegOverAllCLF = path.join(data_file_location, state_gov_nm + 'overall_clf.joblib')
#_X = path.join(data_file_location, state_gov_nm + year_to_process + 'predictions.df')
#_X_CSV = path.join(data_file_location, state_gov_nm + year_to_process + 'predictions.csv')

_train_features_complete = path.join(data_file_location, state_gov_nm + 'train_features_complete.np')
_train_labels = path.join(data_file_location, state_gov_nm + 'train_labels.df')
_test_features_complete = path.join(data_file_location, state_gov_nm + 'test_features_complete.np')
_test_labels = path.join(data_file_location, state_gov_nm + 'test_labels.df')

with open(_train_features_complete,'rb') as f:
    X_train = pickle.load(f)
with open(_train_labels,'rb') as f:
    y_train = pickle.load(f)
with open(_test_features_complete,'rb') as f:
    X_test = pickle.load(f)
with open(_test_labels,'rb') as f:
    y_test = pickle.load(f)

print('after pickle loads')

means = []

state_classifier = state_info['state_clf'][state_id]
params = state_info['state_clf_params'][state_id]

#based on the stored classifier, grab the parameters and load in for each classifier type
if state_classifier == 'MLPClassifier':
    clf = MLPClassifier(**params)
elif state_classifier == 'MultinomialNB':
    clf = MultinomialNB(**params)
elif state_classifier == 'SGDClassifier':
    clf = SGDClassifier(**params)

#train the model    
clf.fit(X_train, y_train)
predicted = clf.predict(X_test)
predicted_prob = clf.predict_proba(X_test)
new_mean = np.mean(predicted == y_test)
means.append(new_mean)

mean=np.mean(np.array(means))
print("overall mean:", mean)
print(classification_report(y_test, predicted, digits=4))

#print('Saving Model File')
from joblib import dump, load
dump(clf, _LegOverAllCLF)
#print('Model Training Complete')
