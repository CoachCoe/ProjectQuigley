from pymongo import MongoClient
from os import environ
import json
import os
from pymongo import errors
import sys

data_file_location = sys.argv[1]

#user = environ.get("OVERLOOK_INTEGRATION_USER")
#password = environ.get("OVERLOOK_INTEGRATION_PWORD")

client = MongoClient('mongodb+srv://ridgebaseaq-docdb-dqrxk.mongodb.net/test'
                        ,username='raq_admin'
                        ,password='OBW2hg18bYurZIO6'
                        ,authSource='admin'
                        ,authMechanism='SCRAM-SHA-1')

database = client['legislative_documents']
collection_bill = database['legiscan_bill_metadata']
collection_people = database['legiscan_people_data']
collection_vote = database['legiscan_vote_data']
collection_text = database['legislative_texts']

too_big_error_list = []

directory = data_file_location

listOfFiles = []
for (dirpath, dirnames, filenames) in os.walk(directory):
    listOfFiles.extend([(dirpath, file) for file in filenames])

#see if it's a json file
#with open('/too_big_errors.txt','w') as ftl:
for filename in listOfFiles:
    if '.json' in filename[1]:
        f = open(os.path.join(filename[0], filename[1]),'r')
        doc_to_load = json.loads(f.read())
        doc_type = list(doc_to_load.keys())[0]
        #check to see what type of file it is, based on the prefix
        if doc_type == 'bill':
            try:
                x = collection_bill.replace_one({'bill_id':doc_to_load['bill']['bill_id']},doc_to_load['bill'],upsert=True)
            except errors.DuplicateKeyError:
                pass
        elif doc_type == 'person':
            try:
                x = collection_people.replace_one({'people_id':doc_to_load['person']['people_id']},doc_to_load['person'],upsert=True)
            except errors.DuplicateKeyError:
                pass
        elif doc_type == 'roll_call':
            try:
                x = collection_vote.replace_one({'roll_call_id':doc_to_load['roll_call']['roll_call_id']},doc_to_load['roll_call'],upsert=True)
            except errors.DuplicateKeyError:
                pass
        elif doc_type == 'text': #in itemname:
            try:
                x = collection_text.insert_one(doc_to_load['text'],upsert=True)
            except errors.DuplicateKeyError:
                pass
                #some documents are too big for mongo this way.  We'll keep a list of the ids that are too big and try to manually insert them later on
                #except errors.DocumentTooLarge:
                #    ftl.write(doc_to_load['text']['doc_id'])