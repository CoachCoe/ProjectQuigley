import pickle
from os import path

data_file_location = 'C:/Users/William Mitchell/Documents/QuigleyData'


with open(path.join(data_file_location,'CAtrain_meta_features.df'),'rb') as f:
    legdata = pickle.load(f)


#with open(path.join(data_file_location,'CA2020WinList.list'),'rb') as f:
#    legdata = pickle.load(f)

print(len(legdata[0]))


"""
passed = 0
failed = 0

for i in legdata:
    if i == 1:
        passed += 1
    if i == 0:
        failed += 1

print('Passed:', passed,'Failed:',failed,'Ratio',passed*1.00/(failed+passed))

"""