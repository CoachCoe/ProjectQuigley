import pickle
import numpy as np
import pandas as pd
import nltk
from nltk.stem.snowball import SnowballStemmer
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfTransformer

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2, f_classif, mutual_info_classif

from pprint import pprint
from time import time
import logging

import warnings
from sklearn.metrics import classification_report
from sklearn.exceptions import ConvergenceWarning
warnings.simplefilter("ignore", ConvergenceWarning)
import sys
from os import path

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

#the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('running', state_gov_nm, year_to_process)

#_LegOverallData_Init = path.join(data_file_location, state_gov_nm + year_to_process + 'LegOverallData.csv')

legcorpus = []
win_state = []
leg_data = pd.DataFrame()
#leg_data = leg_data[0:0]

_LegOverAllCLF = path.join(data_file_location, state_gov_nm + year_to_process + 'overall_clf.joblib')
_X = path.join(data_file_location, state_gov_nm + year_to_process + 'predictions.df')
_X_CSV = path.join(data_file_location, state_gov_nm + year_to_process + 'predictions.csv')

_train_meta_features = path.join(data_file_location, state_gov_nm + 'train_meta_features.df')
_test_meta_features = path.join(data_file_location, state_gov_nm + 'test_meta_features.df')
_train_labels = path.join(data_file_location, state_gov_nm + 'train_labels.df')
_test_labels = path.join(data_file_location, state_gov_nm + 'test_labels.df')

_pre_feature = path.join(data_file_location, state_gov_nm + 'pre_feature.df')

_train_text_features = path.join(data_file_location, state_gov_nm + 'train_text_features.np')
_test_text_features = path.join(data_file_location, state_gov_nm + 'test_text_features.np')
_train_features_complete = path.join(data_file_location, state_gov_nm + 'train_features_complete.np')
_test_features_complete = path.join(data_file_location, state_gov_nm + 'test_features_complete.np')

for i in range(2009, int(year_to_process)+1):
    try:
        _WinList = path.join(data_file_location, state_gov_nm + str(i) + 'WinList.list')
        _legtext = path.join(data_file_location, state_gov_nm + str(i) + 'legtext.corpus')
        _LegOverallData_CSV = path.join(data_file_location, state_gov_nm + str(i) + 'LegOverallData.csv')

        with open(_legtext,'rb') as f:
            legcorpus.extend(pickle.load(f))
        print(i)
        print(len(legcorpus))
        
        leg_data = leg_data.append(pd.read_csv(_LegOverallData_CSV))
        
        print(leg_data.shape)
        
        with open(_WinList,'rb') as f:
            win_state.extend(pickle.load(f))
        
        print(len(win_state))
    except:
        continue

combined_docs = {}
total = 0
passed = 0
leg_target = {}

#for each document, check if it is approved, record that, then combine the list into a string
for doc in legcorpus:
    
    pass_flag = 0
    if doc[0] not in combined_docs:
        total += 1
        try:
            combined_docs[doc[0]] = " ".join(doc[2])
        except:
            pass

leg_targ = pd.DataFrame({"every stage passed":win_state})

bill_order = []
bill_target = []
bill_texts = []

leg_target = {}

for i, bill_id in enumerate(leg_data["bill_id"]):
    if str(bill_id) not in bill_order:
        bill_order.append(str(bill_id))
        bill_target.append(leg_targ["every stage passed"][i])
        leg_target[str(bill_id)] = leg_targ["every stage passed"][i]
        
        if bill_id in combined_docs:
            bill_texts.append(combined_docs[bill_id])
        else:
            bill_texts.append("")

print(len(bill_texts))

features = leg_data
#we do need to assemble all of the data to train the model, and that is best done as close to the training as possible
X = pd.DataFrame(features)

X['leg_targ'] = leg_targ

X = X.drop_duplicates(subset=['bill_id']) #should probably be bill_id
X = X.set_index('bill_id')
X = X.drop(columns=['time_t', 'event'])

#filtering out all types of legislation except bills (no resolutions, constitutional ammendments, etc.)
X = X[X['bill_type']=='B']

bill_order = []
bill_target = []
bill_texts = []

count = 0
for bill_id in X.index:
    if bill_id in combined_docs:
        bill_texts.append(combined_docs[bill_id])
    else:
        bill_texts.append("")
        
X['texts'] = bill_texts

X = X.astype({'year': 'int64'}).sort_values('year', ascending=True)

print(X.shape)
X_new = X[['sponsor_vec', 'proposed_chamber',
            'primary_name','primary_party','number_sponsors',
            'committee_introduced'#,'bill_type'
            ,'month_introduced'#, 'intro_to_end_of_session', 'last_event_to_end_of_session'
            #these features could be useful with more data
            #'primary_leadership','primary_ideology','public_sentiment','press'
            ]].copy()

#this dataset is slightly different than the original
#  print(X['year'].unique())
amount_test = len(X[X['year']==int(year_to_process)])
amount_train = len(X[X['year']<int(year_to_process)])

print(amount_test)
print(amount_train)

with open(_pre_feature,'wb') as f:
    pickle.dump(X[amount_train:amount_train+amount_test],f)