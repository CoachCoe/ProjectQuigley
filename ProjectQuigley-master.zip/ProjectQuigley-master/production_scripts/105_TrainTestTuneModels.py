import pickle
import numpy as np
import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import SGDClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report
from os import path
from pprint import pprint
from time import time
import logging
import sys

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

#data_file_location = 'C:/Users/William Mitchell/Documents/QuigleyData/'

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

#state_gov_nm = 'CA'
#state_id = 5

print('running ', state_gov_nm)

#year_to_predict = 2018

_LegOverAllCLF = path.join(data_file_location,state_gov_nm + 'overall_clf.joblib')
_X = path.join(data_file_location,state_gov_nm + year_to_process + 'predictions.df')
_X_CSV = path.join(data_file_location,state_gov_nm + year_to_process + 'predictions.csv')

_X_train = path.join(data_file_location, state_gov_nm + 'train_features_complete.np')
_y_train = path.join(data_file_location, state_gov_nm + 'train_labels.df')
_X_test = path.join(data_file_location, state_gov_nm + 'test_features_complete.np')
_y_test = path.join(data_file_location, state_gov_nm + 'test_labels.df')

print('before pickle loads')
with open(_X_train,'rb') as f:
    X_train = pickle.load(f)
with open(_y_train,'rb') as f:
    y_train = pickle.load(f)
with open(_X_test,'rb') as f:
    X_test = pickle.load(f)
with open(_y_test,'rb') as f:
    y_test = pickle.load(f)
print('after pickle loads')

means = []
#        n = 1

#print(X_train.shape)

hidden_layer_sizes = [[750],[1000],[750,50],[1000,50],[750,200,50],[1000,500,100,50]]
#hidden_layer_sizes = [[50],[150],[200],[500],[750],[1000],[150,50],[200,50],[500,50],[750,50],[1000,50],[500,100,50],[750,200,50],[1000,500,100,50]]
#hidden_layer_sizes = [[12650],[12650,6325],[12650,6325,3162]]
activation = ['relu','identity','logistic']
max_iter = [100,250,500,750,1000]
solver = ['adam','lbfgs']
alpha = [.01,.001,.0001,.02,.002,.0002,.03,.003,.0003,.04,.004,.0004]
tol = [.001,.002,.003,.004,.005,.006,.007,.008,.009,.01,.015,.02,.05,.1]
n_iter_no_change = [4,8,16,32]

#with open(path.join(data_file_location, state_gov_nm + year_to_process + 'tuninglog.txt'),'w') as f: 
for h in hidden_layer_sizes:
    for r in activation:
        for s in solver:
            for mi in max_iter:
                for a in alpha:
                    for t in tol:
                        for n in n_iter_no_change:
                            params = {   "hidden_layer_sizes": h,
                                            "activation": r,
                                            "max_iter": mi,
                                            "solver": s,
                                            "alpha": a,
                                            "tol": t,
                                            "n_iter_no_change": n
                                            }
                            clf = MLPClassifier(**params)

                            #train the model    
                            clf.fit(X_train, y_train)
                            predicted = clf.predict(X_test)
                            predicted_prob = clf.predict_proba(X_test)
                            new_mean = np.mean(predicted == y_test)
                            means.append(new_mean)

                            mean=np.mean(np.array(means))

                            f = open(path.join(data_file_location, state_gov_nm + year_to_process + 'tuninglog.txt'),'a')
                            print('hidden_layer_sizes:',h,'activation:',r,file=f)
                            print('max_iter:',mi,'solver:',s,file=f)
                            print('alpha:',a,'tol:',t,file=f)
                            print('n_iter_no_change:',n,file=f)
                            print('HiddenLayers:',h,file=f)
                            print("overall mean:", mean,file=f)
                            print(classification_report(y_test, predicted, digits=4),file=f)
                            f.close()

                            #print('Saving Model File')
                            #from joblib import dump, load
                            #dump(clf, _LegOverAllCLF)
                            #print('Model Training Complete')
