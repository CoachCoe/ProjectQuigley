import pickle
import numpy as np

import pandas as pd

from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import SGDClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from os import path
from time import time
import logging
import sys
from joblib import dump, load

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

#the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('Running', state_gov_nm, year_to_process)

_LegOverAllCLF = path.join(data_file_location, state_gov_nm + 'overall_clf.joblib')
_X = path.join(data_file_location, state_gov_nm + year_to_process +'predictions.df')
_X_CSV = path.join(data_file_location, state_gov_nm + year_to_process +'predictions.csv')
_pre_feature = path.join(data_file_location, state_gov_nm + 'pre_feature.df')
_test_features_complete = path.join(data_file_location, state_gov_nm + 'test_features_complete.np')

with open(_pre_feature,'rb') as f:
    X_2020 = pickle.load(f)

with open(_test_features_complete,'rb') as f:
    X_predict = pickle.load(f)

print('Loading Model')
#example of loading a classifier
clf = load(_LegOverAllCLF) 

print('Running Predictions')
predicted = clf.predict(X_predict)
predicted_prob = clf.predict_proba(X_predict)

X_2020 = X_2020[['sponsor_vec', 'proposed_chamber',
                    'primary_name','primary_party','number_sponsors',
                    'committee_introduced','month_introduced'
                    , 'year', 'leg_targ','bill_type'
                ]]

X_2020['OverallPred'] = predicted

Prob = []

for p in predicted_prob:
    Prob.append(p[0])

X_2020['OverallPred_Prob'] = Prob

with open(_X,'wb') as f:
    pickle.dump(X_2020, f)

X_2020.to_csv(_X_CSV)

print('Predictions Completed')