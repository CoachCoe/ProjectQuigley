from pymongo import MongoClient
from os import environ
import json
import os
import sys
#from pymongo import errors
from urllib import request

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
#data_file_location = sys.argv[3]

#user = environ.get("OVERLOOK_INTEGRATION_USER")
#password = environ.get("OVERLOOK_INTEGRATION_PWORD")

client = MongoClient('mongodb+srv://ridgebaseaq-docdb-dqrxk.mongodb.net/test'
                        ,username='raq_admin'
                        ,password='OBW2hg18bYurZIO6'
                        ,authSource='admin'
                        ,authMechanism='SCRAM-SHA-1')

database = client['legislative_documents']
collection_bill = database['legiscan_bill_metadata']
collection_people = database['legiscan_people_data']
collection_vote = database['legiscan_vote_data']
collection_text = database['legislative_texts']

too_big_error_list = []

#this updates the texts based on the doc_ids found in the bill collection
# save failed and updated bill_ids
failed = []
updated = []

print("Getting bills from Mongo...")
documents = collection_bill.find( { "$and": [ { "state": state_gov_nm }, { "session.year_end": int(year_to_process) }, { "bill_type": "B"}, { "texts": { "$ne": [] }} ] } )

# loop through documents returned by above query
for doc in documents:
    t = doc['texts'][len(doc['texts']) - 1]

    #print(t['doc_id'])
    match_doc = collection_text.find_one({'doc_id': {'$eq': t['doc_id']}})
    #print(match_doc.count_documents()))
    if match_doc == None:
        # check if the latest doc_id is in compare_to_collection
        api_url = 'https://api.legiscan.com/?key=9011eadd5033dea81e79297009abc079&op=getBillText&id=%s' % t['doc_id']
        with request.urlopen(api_url) as url:
            # parse json from response
            data = json.loads(url.read().decode())
            if "status" in data and data["status"] == "OK":
                # save the bill text
                text_data = data["text"]
                collection_text.insert_one(text_data)

                updated.append(doc["bill_id"])
                print(f"Saved text for <Bill id: { doc['bill_id'] }, doc_id: { data['text']['doc_id'] }>")
            else:
                # update the list of failed bills
                failed.append(doc["bill_id"])
                errorText = (data['status'] if "status" in data else "No Status") + ": " + (data["alert"] if "alert" in data else "No Alert")
                print(f"ERROR FETCHING <BillText bill_id:{ doc['bill_id'] }, doc_id: { t['doc_id'] }>: { errorText }")

                if "alert" in data and data["alert"] == "API key has been administratively locked":
                    sys.exit("Legiscan API key out of monthly requests!")

print("Summary:")
print("Saved text for bill ids:", end=" ")
print(json.dumps(updated))

print("Failed to fetch bill ids:", end=" ")
print(json.dumps(failed))