from os import path
import pymongo
import pickle
import base64
import sys

mongo_username = 'CEDC_Quigley'
mongo_password = 'lpP9pCcDxQ2Y0tv8'
mongo_server = 'mongodb+srv://ridgebaseaq-docdb-dqrxk.mongodb.net/test'
mongo_authSource = 'admin'
mongo_authMechanism = 'SCRAM-SHA-1'
mongo_database = 'legislative_documents'
mongo_people_collection = 'legiscan_people_data'
mongo_billmeta_collection = 'legiscan_bill_metadata'
mongo_billtext_collection = 'legislative_texts'

client = pymongo.MongoClient(mongo_server
                             , username=mongo_username
                             , password=mongo_password
                             , authSource=mongo_authSource
                             , authMechanism=mongo_authMechanism)
try:
    state_gov_nm = sys.argv[1]
    year_to_process = sys.argv[2]
    data_file_location = sys.argv[3]
except:
    print("Missing Data Error: Enter State Abbreviation, Year, And Directory Path ")
    sys.exit()

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

# the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('running', state_gov_nm, year_to_process)

textLinetoStartAfter = state_info['states_text_start_after'][state_id]
usetextLinetoStartAfter = False

database = client[mongo_database]
collection = database[mongo_billmeta_collection]

bill_data = []
bill_ids = []

try:
    # make sure the query returns data so that we can make the files and continue
    query = collection.count_documents({"$and": [{"state": state_gov_nm}, {"session.year_end": int(year_to_process)}]})
    if query > 0:
        _legtext_raw = path.join(data_file_location, state_gov_nm + year_to_process + 'legtext_raw.corpus')
        # _legtext = path.join(data_file_location, state_gov_nm + year_to_process + 'legtext.corpus')
        _raw_bill_metadata = path.join(data_file_location, state_gov_nm + year_to_process + 'raw_bill_metadata.list')

        for bl in collection.find(
                {"$and": [{"state": state_gov_nm}, {"session.year_end": int(year_to_process)}]}).batch_size(30):
            bill_data.append(bl)
    else:
        raise Exception("ERROR NO MONGO DATA FOR: STATE: " + state_gov_nm + ", YEAR: " + str(year_to_process))
except Exception as e:
    print(e)
    sys.exit()

for bill in bill_data:
    bill_ids.append(bill['bill_id'])

with open(_raw_bill_metadata, 'wb') as f:
    pickle.dump(bill_data, f)

# switch to the legislative texts
database = client[mongo_database]
collection = database[mongo_billtext_collection]

legtext_corpus = [[0, 0, ['dummy', 'entry']]]

count = 0

legtext_corpus = []
failed = []

try:
    for bl in collection.find({'bill_id': {'$in': bill_ids}}).batch_size(30):
        if bl['mime'] == 'text/html':
            message_bytes = base64.b64decode(bl['doc'])
            try:
                message = message_bytes.decode('unicode_escape')
            except:
                failed.append(bl)

        elif bl['mime'] == 'application/pdf':
            try:
                message = base64.b64decode(bl['doc'])
            except:
                failed.append(bl)  # appends current

        try:
            legtext_corpus.append([bl['bill_id'], bl['doc_id'], message, bl['mime']])
        except:
            failed.append(bl)

except Exception as e:
    print("Error: ", e)

# save a raw form of the corpus text
with open(_legtext_raw, 'wb') as f:
    pickle.dump(legtext_corpus, f)

# error File
with open("Error_File.txt", "a") as f:
    for item in failed:
        f.write(item)