import  pickle
from datetime import date
import sys
from os import path

data_file_location = sys.argv[1]

#state id is the list index + 1
state_dict = {
'states_abbrev' : [
'UK'  #0
,'AL' #1
,'AK' #2
,'AZ' #3
,'AR' #4
,'CA' #5
,'CO' #6
,'CT' #7
,'DE' #8
,'FL' #9
,'GA' #10
,'HI' #11
,'ID' #12
,'IL' #13
,'IN' #14
,'IA' #15
,'KS' #16
,'KY' #17
,'LA' #18
,'ME' #19
,'MD' #20
,'MA' #21
,'MI' #22
,'MN' #23
,'MS' #24
,'MO' #25
,'MT' #26
,'NE' #27
,'NV' #28
,'NH' #29
,'NJ' #30
,'NM' #31
,'NY' #32
,'NC' #33
,'ND' #34
,'OH' #35
,'OK' #36
,'OR' #37
,'PA' #38
,'RI' #39
,'SC' #40
,'SD' #41
,'TN' #42
,'TX' #43
,'UT' #44
,'VT' #45
,'VA' #46
,'WA' #47
,'WV' #48
,'WI' #49
,'WY' #50
,'DC' #51
,'US' #52
]
,'states_text_start_after' : 
[
'UK','AL','AK','AZ','AR'
,'the people of the state of california do enact as follows' #CA
,'CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA'
,'ME','MD','MA','MI','MN','MS','MO'
,'MT','NE','NV'
,'in the year of our lord' #NH
,'NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'
,'DC','US'
]

,'states_win_keywords': [
    [] #UK
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor'] #AL
    ,['permanently filed','effective date(s) of law'] #AK
    ,['chapter']#AZ
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#AR
    ,['adopted','chaptered by secretary of state']#CA
    ,['signed by the speaker','signed by the president','sent to the governor','governor signed']#CO
    ,['public act']#CT
    ,['signed by governor']#DE
    ,['adopted','chapter no']#FL
    ,['adopted','passed','read and adopted','act']#GA
    ,['resolution adopted','resolutions sent']#HI
    ,['chapter','signed by governor']#ID
    ,['public act']#IL
    ,['adopted voice vote','public law']#IN
    ,['signed by governor']#IA
    ,['enrolled','approved by governor']#KS
    ,['signed by governor','delivered to secretary of state', 'adopted by voice vote']#KY
    ,['read by title and adopted','enrolled']#LA
    ,['passed to be enacted']#ME
    ,['approved by the governor']#MD
    ,['signed by the governor','enacted']#MA
    ,['adopted']#MI
    ,['adopted']#MN
    ,['enrolled bill']#MS
    ,['adopted']#MO
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#MT
    ,['president/speaker signed']#NE
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#NV
    ,['signed', 'enrolled', 'law without signature', 'introduced and adopted']#NH
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'NJ'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'NM'
    ,['signed','veto','vetoed']#'NY'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'NC'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'ND'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'OH'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'OK'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'OR'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'PA'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'RI'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'SC'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'SD'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'TN'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'TX'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'UT'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'VT'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'VA'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'WA'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'WV'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'WI'
    ,['delivered to governor','assigned act no','ebnrolled','enrolling','passed','sent to governor']#'WY'
    ,[]#'DC'
    ,['presented to president']#'US'
    ]


,'states_event_keywords':[
   [] #UK
    ,['read','first time','ways and means','education','governmental affairs'
        ,'introduced','rules','public safety','homeland security','finance','taxation'
        ,'judiciary','local legislation','state government','general fund','referred to','motion to'
        ,'voice vote','third time','second time','pending','as favorable','ammendment offered','health','county and municipal government'
        ,'transportation','energy','veterans','military affairs','fiscal responsibility','economic development','agriculture','forestry'
        ,'cosponsors added','acted on','delivered','passed','insurance','ethics', 'campaign finance', 'tourism','education policy'
        ,'constitution','campaigns','elections','children','senior advocacy','county legislation','technology','research','urban','rural','development'
        ,'rereferred','adopt','delivered to','forwarded to','governor','engrossed','banking','delivered to governor','assigned act no']#'AL'
    ,['referred to','withdrawn by sponsor','cosponsor(s)','returned to','state affairs','finance','labor', 'commerce','resources','education'
        ,'judiciary','community', 'regional affairs', 'health', 'social services','rules','transportation','energy','rls'
        ,'tribal affairs','arctic policy','read the first time','effective date(s) of law','economic dev','tourism'
        'transmitted to governor', 'fisheries','report received','permanently filed', 'progress report'
        ]#'AK'
    ,['read second time','transmit to','house','senate','majority caucus','minority caucus','prefile','do pass','do pass amended'
        ,'chapter','committee action','trans','hhs','tps','ed','rules','jud','whole action','voting','mva','wm','approp','secretary of state'
        ,'gov','discussed', 'held','withdrawn','ra','ps','failed','third reading','first reading','assigned to','failed to pass','motion', 'reconsider'
        'lag','nrew','elect','tech','passed','fin','proper','consideration','floor','ammendment'
        ]#'AZ'
    ,['enrolled','delivered to','governor','failed','adoption','read','first time','second time','third time','adopted','rules suspended'
        ,'notification','is now act','emergency clause','withdrawn','by author','placed on the calendar'
        ]#'AR'
    ,['in committee','hearing','postponed','by committee','read', 'returned to','secretart of state','referred to','rls'
        ,'health','ed','bp','pub s','go','jud','ins','nat res','b fr','assignment','appr'
        ,'gov  f','veto','sustained','held','under submission','trans','l e','rev tax','from committee'
        ,'ordered','inactive file','on request','introduced','e u c','pub s','e r','do pass'
        ,'va','u e','l gov','died','amended','re-referred','budget','p cp','h cd', 'first', 'second', 'third']#'CA'
    ,['signed','governor','sent to','signed by','speaker','introduced','house','senate','postpone','indefinitely'
        ,'committee','state','veterans','public health care','human services','no amendments','whole','military affairs','judiciary'
        ,'first reading','second reading','third reading','assigned to','finance','labor','business affairs','education','appropriations'
        ,'unamended','rural affairs','agriculture','technology','business','discussion only'
            ]#'CO'
    ,['public','hearing','referred to','joint committee','office of','legislative research','fiscal analysis','transportation','adopted','senate'
        ,'house','appropriations','veterans affairs','environment','children','higher education','employment advancement','housing','labor'
        ,'public employees','public safety','security','insurance','real estate','revenue','bonding','planning and development','judiciary'
        ,'file number','motion','failed','no action','act','rules suspended','transmitted to','commerce','general law'
        ]#'CT'
    ,['signed by','governor','passed','senate','house','introduced','assigned to','administration','stricken','appropriations'
        ,'economic development','banking','insurance','commerce','judiciary','judicial','business','transportation','public safety'
        ,'education','executive','revenue','finance','land use','infrastructure','natural resources','health','human development'
        ,'elections','community affairs','sunset','policy analysis government accountability','social services','reported out','adpoted','in lieu of','original bill'
        ,'capital improvement','agriculture']#'DE'
    ,['indefinitely','postponed','died','on calendar','ordered','enrolled','appropriations','criminal justice','subcommittee','infrastructure'
        ,'security','judiciary','rules','health policy','innovation','industry','terchnology','education','community affairs'
        ,'publication','withdrawn','prior','introduction','engrossed','criminal justice','civil justice','adopted','introduced'
        ,'finance','tax','ethics','elections','local','federal','ways and means','natural resources','energy'
        ,'utilities','transportation','tourism','economic development','gaming control','higher education','appropriations','judiciary','laid on table']#'FL'
    ,['house','senate','adopted','read','second','readers','effective date','referred','tabled','second time'
        ,'withdrawn','first readers','hopper','prefiled','passed','substitute','favorably','reported','postponed'
        ,'act','notice','reconsider','agreed','disagreed','amend','third reading','lost','veto']#'GA'
    ,['deleted','deferred','transmitted to governor','recommendation', 'not adopted'
        ,'hearing cancelled','passed with amendments','passed unamended','public hearing', 'scheduled','adopted','re-referred','passed second reading'
        ,'receceived notice of disagreement','received from', 'senate','one day notice','certified copies sent','carried over','48 hrs notice'
        ,'WLH', 'TRN', 'TIA', 'PVM', 'LHE', 'LAB', 'JUD', 'HSH', 'HLT'
        , 'EEP', 'CPC', 'WTL', 'WAM', 'TRS', 'CPH', 'LCA', 'HSH', 'LAB'
        , 'JDC', 'HWN', 'GVO', 'HLT', 'FIN', 'EET', 'HSG', 'EDU', 'EDB'
        , 'IUD', 'AGR', 'AEN', 'HRE', 'HOU', 'PVM', 'PSM', 'JAC', 'LMG'
        , 'PSM']#'HI'
    ,['held at desk' ,'referred','state affairs', 'transportation', 'defense' ,'delivery of','filed','secretary of state', 'chief clerk', 'secretary of senate'
        , '14th order','introduced','read','first time','referred','education', 'appropriations', 'judiciary', 'rules','administration', 'resources', 'conservation'
        ,'ways means', 'agricultural affairs', 'commerce','human resources', 'business', 'education', 'environment', 'energy','technology', 'health', 'welfare'
        , 'local government', 'revenue', 'taxation', 'second time','amended in', 'house','senate','filed for','third reading','report', 'printed','signed'
        ,'order delivered','retained','returned','vetoed','session law','take bill off general orders','hold place']#'ID'
    ,['vote','required','added','alternate','chief','cosponsor','adopted','both','changed','remove','sponsor','approved','consideration','assignments','rules'
            ,'committee','arrive','senate','house','assigned','adoption','child welfare','agriculture','appropriations','capital'
            ,'elementary','secondary','education','general','services','higher','human','public','safety','child care accessibility','early childhood'
            ,'cities','villages','commerce','economic development','consumer protection','counties','townships','law','cybersecurity'
            ,'data analytics','economic opportunity','equity','administration','license','charter school','school curriculum','policies','energy'
            ,'environment','conservation','executive','appointments','financial institutions','ethics','government accountability','health care availability'
            ,'accessibility','insurance','international trade','judiciary','civil','criminal','labor','activities','local','special','oversight','medicaid managed care'
            ,'mental','museums','arts','cultural enhancements','personnel','pensions','prescription drug affordability','revenue','finance','balanced budget'
            ,'note','filed','correctional','withdrawn','do pass','short debate','effective date','secretary'
            ,'telecommunications','information technology','transportation','regulation','roads','bridges','vehicles','veterans affairs','request','inapplicable'
            ,'amended','bill','dead','veto','ammendatory','override','clerk','deadline extended','final action','first','second','third','read','governor','approved'
            ,'held','fiscal','calendar','order','standard debate','concurs','floor','table','state','debt','impact','recommend','voice','motion'
            ,'prevailed','suspend','immediate','land conveyance appraisal','afforability','judicial','passed','placed','postponed','remains','report'
            ,'verified','waive','posting','notice','stands','administrative','substantive','agency operation','amusement','online','gaming','broadband access'
            ,'business','industry','procedure','innovation','commercial','constitutional','enforcement','family','firearm','process','hydraulic fracturing'
            ,'income tax','informed consent','job growth','preservation','training','juvenile justice','system involved youth','retirement system'
            ,'managed care','miscellaneous issues','negotiations','reform','property tax','benefits','regulatory matters','renewable initiative'
            ,'sales','amusement','other taxes','sentencing','penalties','sex offenses','sex offender registration','cannabis','rights'
            ,'clear compliance','election','interscholastic athletics','procurement','tax exemptions','credit','tort reform','traffic','unemployment'
            ,'tort liability','utility rate','policy','wage','workforce development','chair','sustain','session','sine die','refer','resolution','lost']#'IL'
    ,['withdrawn','vetoed','third reading','added','coauthors','second author','third author','advisors appointed','ordered engrossed','rules suspended','conference committee'
        ,'adopted by sentate','second reading','returned to senate','returned to house','cosponsor added','reassigned','ways and means', 'elections and apportionment', 'courts and criminal code'
        , 'commerce', 'small business','economic development', 'agriculture','rural development',' natural resources', 'local government', 'judiciary', 'inurance', 'health','provider services'
        , 'government and regulatory reform', 'family', 'children' ,'human affairs',  'pensions', 'labor', 'public policy', 'public health',  'roads','transportation', 'utilities'
        , 'tax', 'fiscal policy', 'rules','legislative procedures', 'insurance', 'financial institutions', 'homeland security', 'transportation', 'corrections','criminal law'
        ,'house advisors appointed' ,'voice vote','committee report','adopted','standing vote','amend','amenedment prevailed']#'IN'
    ,['adopteded','amendment filed','attached to companion','attached to similar','committee amendment','committee report approving bill','renumbered','committee report','approving bill'
        ,'recommendng amendment ','passage','recommendng passage','explanation of vote','fiscal note','final action','immediate message','revised','introduced','passed on file','placed on calendar'
        ,'item vetoed','signed by governor','laid over under rule','message from house','message from senate','motion filed','reconsider vote','noba','house full approps','senate full approps'
        ,'senate sub','passed on file','read first time','reported out','resolution adopted','resolution filed','sent to secretary of state','sponsor added','sponsor withdrawn'
        ,'subcommittee meeting','subcommittee reassigned','subcommittee recommends','withdrawn','ways and means', 'agriculture', 'appropriations', 'commerce', 'economic growth'
        , 'education','environmental protection', 'human resources', 'judciary', 'labor', 'local government', 'natural resources', 'public safety', 'rules', 'administration'
        , 'state govrnment', 'transportation', 'veterans affairs']#'IA'
    ,[]#'KS'
    ,[]#'KY'
    ,[]#'LA'
    ,[]#'ME'
    ,[]#'MD'
    ,['accompanied','new draft','placed','on file','adopted','ammendement','house','senate','ways and means'
        ,'as ammended','in concurrence','by substitution','striking out','reading','first','second','third','bonding','capital expenditures'
        ,'state assets','rejected','withdrawn','as changed','agreed to','bill','reported','referred','favorably','steering','policy','scheduling'
        ,'rules','health care financing','placed','orders of the day','joint','committee','special','report','accepted','called','consideration'
        ,'conference','appointed','ought to pass','inserting', 'in place','substituting','recommended','next session','next sitting'
        ,'pending','discharged','cannabis','children','consumer protection','professional licensure','families','persons with disabilities','education'
        ,'elder affairs','election laws','financial services','environment','natural resources','agriculture','higher education','housing'
        ,'labor','workforce development','mental health','substance abuse','recovery','municipalities','regional government','health'
        ,'public','service','homeland','security','revenue','telecommunications','utilities','energy','state','administration','regulatory', 'oversight'
        ,'veterans','federal','affairs','judiciary','transportation','enacted','emergency','preamble','laid before','governor', 'governors','as section','for actions'
        ,'for message','further','returned','veto','vetoes','filed','hearing','scheduled','rescheduled','laid aside','lay on table','motion','recommit'
        ,'reconsider','suspend','negatived','prevailed','order','new text','ought not to pass','favorably','ordered','read','passed over','passed to be','engrossed'
        ,'tourism','arts','cultural development','signed by'
        ]#'MA'
    ,['adopted','referred','re-referred','reassigned','removed','excused','placed','postponed','laid over','read','reported','named','printed','assigned'
        ,'government operations','judiciary and public safety','appropriations','regulatory reform','transportation and infrastructure' ,'finance','ways and means','judiciary','reproduced'
        ,'environmental quality','natural resources','insurance banking','oversight','education career readiness','whole','economic small business development','health policy','families seniors and veterans'
        ,'transportation','agriculture','elections','secretary for record','natural resources' ,'outdoor recreation','energy technology','commerce','tourism','appropriations','education','appropriation'
        ,'local government','military veterans and homeland security','adopted unanimous standing vote' ,'adopted senate','third reading','government operations','senate','order resolutions','families children and seniors'
        ,'tax policy','financial services','commerce and tourism','joint resolution','rule 41','transportation infrastructure','advice consent','communications technology','elections ethics'
        ,'energy']#'MI'
    ,['referred','added','adopt','postponed','withdrawn','returned','filed','re-referred','laid','prevailed','recall','stricken','changed','substituted','introduced','capital investment','taxes'
        ,'second reading','judiciary and public safety','finance','policy','environment','natural resources policy','legacy','state government ','elections','transportation','rules and administration'
        ,'jobs and economic','growth','capital investment','human services','reform','first reading','tax','government operations','commerce','education','consumer protection','transportation'
        ,'environment','natural resources','jobs and economic development','higher education','public safety','criminal justice','civil law division','utilities','local','property','agriculture'
        ,'rural','housing','family care and aging','veterans','military affairs','labor','ways and means','early childhood','energy and climate','water division','long-term care','motion'
        ,'bill','rules and legislative']#'MN'
    ,['adopted','approved','died','enrolled','failed','release','reconsider','passed','referred','re-referred','tabled','transmitted','pass','signed','committee','calendar','bill','motion','accountability'
        ,'efficiency','transparency','appropriations','conservation and water resources','county affairs','judiciary','ways and means','agriculture','finance','apportionment and elections','constitution'
        ,'universities and colleges','corrections','drug policy','education','energy','forestry','transportation','insurance','division','labor','lcan and private','legislation','marine resources'
        ,'medicaid','military affairs','municipalities','public health and human services','public property','public utilities','rules','tourism','wildlife','fisheries and parks'
        ,'workforce development']#'MS'
    ,['postponed','adopted','approved','authorized','combined','withdrawn','delivered','dropped','reported','cancelled','conducted','scheduled','perfected','offered','placed','referred','removed'
        ,'reported','re-referred','voted','signed','pass','committee','tourism','bill','formal','ways and means','bills','hearing','children and families','elections and elected officials','veterans'
        ,'agriculture','food production','outdoor resources','appropriations','commerce','consumer protection','energy and the environment','economic development','education','general laws','government reform'
        ,'health and pensions','insurance and banking','judiciary and civil and criminal jurisprudence','seniors','small business and industry','transportation','infrastructure','public safety','military affairs'
        ,'economic development','laid over','house rules','calendar','elementary and secondary education','judiciary','local government','professional registration and license','disease control and prevention'
        ,'regulatory oversight and reform','joint rules','resolutions and ethics','agriculture policy','budget','consent and house procedure','conservation and natural resources','crime prevention and public safety','government'
        ,'health','mental health','education','pensions','oversight','aging','career readiness','small','student accountability','urban issue','transportation','utilities','read','first','speaker'
        ]#'MO'
    ,[]#'MT'
    ,['title printed', 'carryover', 'president/speaker signed', 'placed on', 'approved by', 'notice of', 'referred to', 'postponed','withdrawn', 'name added', 'laid over', 'priority', 'approval'
        ,'returned by', 'certificate', 'failed', 'amended', 'opinion','filed', 'pending', 'name withdrawn', 'passed over', 'placed on','reported to']#'NE'
    ,[]#'NV'
    ,['amendment adopted','bill killed','children and family law','commerce'
        ,'committee','committee amendment','report','consumer affairs','criminal justice'
        ,'died on table','education','election law','energy','environment and agriculture'
        ,'executive departments and administration','executive session','finance','fish and game'
        ,'hearing','inexpedient to legislate','interim study'
        ,'internal affairs','introduced','judiciary','labor, industrial and rehabilitative services'
        ,'lay on table','legislative administration','majority committee report'
        ,'minority committee report','motion adopted','motion failed'
        ,'moved inexpedient to legislate','municipal and county government','natural resources'
        ,'ought to pass','ought to pass with amendment','public'
        ,'public works and highways','referred to','removed from consent'
        ,'resources, recreation and development','retained in committee','science, technology'
        ,'state-federal relations','to be introduced','transportation','vacated to','voice'
        ,'vote','ways and means','without objection','elderly affairs','workforce development'
        ,'municipal affairs','health','human services','veterans affairs','marine resources'
        ,'public safety','vacated and referred to','vacated from','enrolled','signed', 'special order'
        ,'subcommittee', 'work session','retained bill','cancelled','rescheduled','next session day'
        ,'beginning of regular calendar','law without signature', 'continued','recessed','vetoed'
        ,'veto sustained','floor amendment','house non-concurs with senate','senate non-concurs with house'
        ,'speaker appoints','speaker appoints alternates','request for committee of conference','accedes to'
        ,'requests cofc','request cofc','request committee of conference','requests committee of conference', 'introduced and adopted'] #NH
    ,['introduced', 'referred to', 'withdrawn', 'reported', 'filed', 'passed'
        , 'received', 'approved', 'combined', 'emergency'
        , 'motion', 'table', 'amendment', 'substituted', 'transferred'
      ]#'NJ'
    ,['not printed', 'signed', 'reported', 'sent', 'referred', 'not referred',    'tabled', 'passed', 'do not pass recommendation', 'do pass recommendation', 'failed', 'veto', 'succeeding', 'died'
      ]#'NM'
    ,[   '1st','report','reading','2nd','3rd','adopted','advanced to','first','second','third','amend','recommit','aging','agriculture'
         ,'alcoholism','drug abuse','substance abuse','banks','budget','revenue','children and families','cities','civil service','pensions'
         ,'codes','commerce','economic development','small business','consumer affairs','protection','correction','corporations','authorities','commissions'
        ,'crime victims','crime','cultural affairs','tourism','parks','recreation','domestic animal welfare','education','election law','elections','energy'
        ,'telecommunications','environmental conservation','ethics','internal governance','finance','governmental employees','governmental operations'
        ,'health','higher education','housing','construction','community development','insurance','internet','technology','investigations','judiciary'
        ,'labor','libraries','education technology','local government','mental health','developmental disabilities','new york city education'
        ,'racing','wagering','gaming','real property taxation','rules','social services','arts','sports development','transportation'
        ,'homeland security','veterans','military','ways and means','infrastructure','capital development','subcommittee','womens issues','restoring','original print'
        ,'amended','approval memo'
        ,'assigned','immediate effect','by resolution','reintroduced','retained','present status','chapter','committed','committee','discharged'
        ,'considered by','defeated','delivered','assembly','senate','secretary of state','governor','died','disapproved','appropriations'
        ,'held','consideration','enacting','clause','stricken'
        ,'line','veto','home','request','lost','motion','roll call','vote','carried','filed','override','lay upon','postpone','notice','petition'
        ,'reconsider','requested','withdrawn','ordered','opinion','special','passed','print number','public','hearing','recalled','reference'
        ,'changed','referred','calendar','regulatory reform','reported','returned','restored','signed','star','removed','substituted','substitution'
        ,'tabled','taken','table','thru','attorney','general','vetoed','reconsidered'
      ]#'NY'
    ,['serial referral','operations of house','added','stricken','judiciary','sequential referral','operations of senate','re ref to','transportation','finance','com on state and local'
        ,'if favorable','appropriations','general government','regulatory reform','insurance','health','base budget','environment','commerce','justice','public safety','state and local'
        ,'redistricting and elections','pensions and retirement','approp base budget','health care','edu/higher edu','commerce and insurance','natural resources','agriculture','environment'
        ,'transport','select committee','re ref com on','human services','education','homeland security','verteran affairs','election and ethic','economic resources','agriculture and natural'
        ,'alchoholic beverage','reptd unfav','if favorable','public utilities','state and local','edu k12','edu universities','Ch. SL','Ch. Res','adopted','failed to override','reappointed'
        ,'conferess changed','conf witdrawn','conf appointed','redistricting']#'NC'
    ,['withdrawn from','signed by govenor','veto','second reading','lacks constitutional major','failed to pass','failed to adopt','motion to reconsider','on table','failed','filed with'
        ,'secretary of state','committee hearing']#'ND'
    ,['adopted','rules','intoduced','refer to committee','state and local','health','ways and means','transportation','public safety','commerce and workforce','criminal justice','finance'
        ,'judiciary','oversight','reported','human services','medicaid','primary ','secondary education','commerce and labor','general government','agency review','local government'
        ,'veteran affairs','passed','education','insurance','financial institutions','natural resources','workforce development','offered','rural development','introduced and referred'
        ,'armed services','public utilities','federalism','finance subcommittee','higher education','insist amendments','committee of conference','longterm care','reported substitute'
        ,'effective','reported amended','re referred','rules reference','concurred','senate amendments','provisions','appropriations','emergency','reappropriation','operating appropriations'
        ,'tax levy','certain provisions','current expenses']#'OH'
    ,['witdrawn from','veterans','military affairs','direct to calendar','utilities','transportation','tourism','rules','public safety','public health','judiciary','insurance','health services'
        ,'long term care','government efficiency','energy','natural resources','county and municipal','family services','business commerce','banking','financial services','pensions','appropriations'
        ,'budget','agriculture','rural dev','admin rules','vetoed','title stricken','title restored','third reading','second reading','measure failed','rescinded','referred to','wildlife'
        ,'military affairs','finance committee','approp committee','transport committee','rules committee','retirement insurance','retire insur commit','pub safe commit','judiciary committee'
        ,'joint committee','higher edu','career tech','human services','gov efficiency','general gov commit','general gov','finance','energy commit','education commit','education','common edu'
        ,'approp and budget','wildlife committee','agriculture and wildlife','SC named','SA rejected','SA recieved','conference requested','naming conference','report do pass'
        ,'ammended by committee','CR filed','JCR filed','pass as amended','remove representative','principal house','remove as coauthor','remove as author','authored by','remains third reading'
        ,'reject of SA','transport sub','public safety sub','agencies sub','regulatory service sub','human serv sub','gen gov sub','finance subcommittee','educatiom subcommittee','appr/sub'
        ,'actuary pursuant','recommendation','full committee','general order','motion expired','laid over','introduced','has read','considered and deferred','filed with','failed in','enrolled'
        ,'clause stricken','clause restored','enacting','emergency restored','emergency removed','emerg stricken','emergency added','died in conference','CR','coauthored by','CCR submitted'
        ,'CCR read','CCR failed adopt','CCR adopt rescind','govenors signature']#'OK'
    ,['session held','emergency preparedness','referred to','hearing held','in committe','adjournment','first reading','speakers desk','filed with','secretary of state','chap one laws'
        ,'chap two laws','chap three laws','effective date','presidents desk','at desk']#'OR'
    ,['introduced','referred','adopted','re-referred','removed','re-committed','transmitted','re-reported','presented','reported','amended','passed','laid on the table','consideration','discharge'
        ,'final','veto','judiciary','state','local','government','education','finance','transportation','labor and industry','health','appropriations','veterans' ,'emergency preparedness','environmental resources'
        ,'energy','agriculture','human services','affairs','consumer','protection','professional licensure','commerce','insurance','children','youth','game','fisheries','banking','law','justice'
        ,'rules','economic','recreational development','urban','tourism','executive nominations','liquor control','housing','gaming oversight','aging','older adult','intergovernmental operations','communications'
        ,'technology','general assembly','governor']#'PA'
    ,['recommended','recommends','introduced','referred','read','passed','withdrawn','postponed','effective','signed','heard','transferred','placed','scheduled','further study','house','finance'
        ,'senate','judiciary','h.e.w','education','health','human services','corporations','labor','housing','municipal','government','signature','governor','commerce','environment','agriculture','passage'
        ,'special legislation','veterans','affairs','rules','ethics','oversight','calendar','education','natural resources','consideration']#'RI'
    ,['introduced','adopted','referred','returned','corrected','read','placed','request','recommitted','adjourned','added','recalled','amended','reconsidered','committed','concurred','rejected'
        ,'removed','judiciary','labor','commerce','industry','concurrence','finance','ways and means','education','public works','transportation','medical','affairs','agriculture','natural resources'
        ,'fish','game','forestry','medical','military','public','municipal','banking','insurance','environmental','invitations','memorial resolutions','family','veterans','services','rules','calendar'
        ,'corrections','penology','delegation']#'SC'
    ,['signed','withdrawn','deferred','tabled','passed','concurred','delivered','amended','failed','motion','reconsidered','veto','consideration','governor','judiciary','prime','sponsor','agriculture'
        ,'natural resources','commerce','energy','appropriations','house','committee','senate','state','affairs','taxation','health','human services','joint','secretary','education','representatives'
        ,'local government','military','veterans','calendar','conference','transportation']#'SD'
    ,['signed','canceled','held','pending','passed','withdrawn','concurred','deferred','rcvd','assigned','returned','transmitted','placed','re-refer','reset','taken','failed','recommended','ref'
        ,'engrossed','reassigned','received','filed','introduced','reset','recalled','enrolled','adjourned','tabled','re-ref','suspended','refused','recede','transmission','governor','meeting','speaker'
        ,'consideration','senate','judiciary','committee','state','local','government','education','commerce','labor','clerk','health','welfare','finance','ways','means','subcommittee','budget','revenue'
        ,'fwm','transportation','safety','energy','resources','departments','agencies','operations','agriculture','natural resources','k-12','elections','campaign','constitutional protections','sentencing'
        ,'criminal','justice','welfare','public','service','employees','calendar','energy','civil','facilities','regulations','property','planning','counties','cities','curriculum','testing','innovation'
        ,'higher education','funding','tenncare','employee','children','families','summer','study','naming','designating','private acts','mental','substance','abuse','utilities','infrastructure','corrections'
        ,'banking','investments','property','casualty','tacir','fmw']#'TN'
    ,['reported','enrolled','left','pending','effective','referred','authorized','laid','placed','signed','received','no action','taken','considered','vetoed','sent','withdrawn','filed','failed'
        ,'returned','recorded','appoints','postponed','scheduled','adopts','transmitted','recommitted','cancelled','committee','calendar','state','affairs','business','commerce','health','human services'
        ,'transportation','public','education','criminal','justice','ways','means','elections','jurisprudence','homeland','security','safety','governor','natural resources','economic','development'
        ,'house','licensing','administrative','procedures','pensions','investments','financial','environmental','regulation','water','rural','finance','intergovernmental','insurance','business'
        ,'culture','recreation','tourism','relations','resource','vet','border','security','juvenile','justice','family','corrections','livestock','administration','defense','redistricting','motion'
        ]#'TX'
    ,['1st reading','2nd reading calendar','became law','bill prepared','bills','circled in senate','clerk of the house','draft of enrolled bill prepared','enrolled','enrolling','executive branch'
        ,'filed in house','filed in senate','filed in','filing','fiscal analyst','for filing','general counsel','governor declined to sign','governor signed','governor vetoed','governor','house rules committee'
        ,'house speaker','house','legislative research','lieutenant governors office','line item veto','not passed','received fiscal note','senate file','senate','sent for enrolling','signed by president'
        ,'w/o governors signature']#'UT'
    ,['adopted by','adopted in concurrence','adopted','agreed to','agriculture and forestry','agriculture','allowed to become law','amendment','appropriations','as passed by','at the same time'
        ,'as members of the','be relieved of the bill','bill committed to','bill was withdrawn','bill','by committee','by motion of','commerce and economic development','committed to committee on','committee bill read the first time'
        ,'committee bill','committee on transportation','committee on','corrections and institutions','delivered to secretary of state','economic development housing and general affairs','education'
        ,'energy and technology','favorable report','finance','fish','general','government operations','governor approved','governor vetoed bill' ,'health and welfare','health care','house concurred'
        ,'house','house proposal of amendment concurred in','housing','human services','in senate proposal','institutions','judiciary','military affairs','messaged to the house forthwith','motion agreed to','motion to withdraw'
        ,'moved to recommit the bill to','moved that the committee on','natural resources and energy','natural resources','not introduced','notice calendar','on motion of','on the part of the house','ordered'
        ,'passed in concurrence','per joint rule','per rule','per senate rule','placed on','proposal of amendment','pursuant to senate rule','read 1st time','read and adopted','read adopted','read first time'
        ,'recommendation of amendment to be offered by','recommitted to','referred to committee','referred to','rules suspended','second reading','senate and house','senate message','senate','signed by governor'
        ,'speaker appointed','third reading ordered','the same be committed to the committee on','third reading','treated as bill','temporary','transportation','unfinished business','ways and means','wildlife'
        ,'with recommendation of amendment','which was agreed to','without governors signature']#'VT'
    ,['act of assembly','adoption','agreed to by senate','agriculture conservation and natural resources','agriculture','appropriations','approved by','bill reprinted','bill text as passed','bill text'
        ,'by appropriations','by voice vote','chapter text','chapter','chesapeake','cities','commerce and labor','committee substitute','communications, technology, and innovation','conference report agreed to'
        ,'continued to 2021','counties','courts of justice','defeated','defeated by senate','education and health','education','election by senate','enacted','engrossment','failed to pass','failed to report'
        ,'finance and appropriations','finance','general laws','governor','governors recommendation','governors substitute printed','health welfare and institutions','health','house and senate','house calendar'
        ,'house vote','in appropriations','in education','in finance','in house','in judiciary','incorporated by','incorporated','incorporates','judiciary','labor and commerce','left in judiciary','left in'
        ,'local government','natural resources','passed by indefinitely','passed','privileges and elections','public safety','read third time and defeated by senate','read third time','received by house'
        ,'received by senate','reconsideration rejected','reconsideration refused','rehabilitation and social services','rejected','report agreed','requires affirmative votes','rules with letter','rules'
        ,'senate and house','senate','stricken at request of patron','stricken from docket','subcommittee recommends','tabled in','tabled in rules','technology','towns','transportation','vetoed by','with amendments'
        ,'with letter','with substitute']#'VA'
    ,['2 review','adopted by','adopted','agriculture water natural resources parks','agriculture','appropriations','behavioral health subcommittee to health long term care','behavioral health subcommittee','bill did not receive sufficient votes'
        ,'but not heard','by resolution','capital budget','civil rights judiciary','college workforce development','commerce and gaming','community development','conference committee appointed','consumer protection business','did not receive sufficient votes'
        ,'early learning K-12 education','economic development','education','effective date','environment energy','environment energy technology','executive session scheduled','filed with' ,'finance','financial institutions','first reading'
        ,'for second reading','for third reading','governor voted','health long term care','health care wellness','higher education workforce development','house committee','house refuses to concur','house rules 3','house rules committee','house rules'
        ,'housing stability affordability','housing','human services early learning','human services reentry rehabilitation','human services','in house committee','in present status','in present status','in senate amendments','in the house committee'
        ,'in the senate committee','innovation technology economic development','labor commerce','labor workplace standards','law justice','local government','natural resources','no action was taken','not heard in','on motion','on motion','passed to rules committee'
        ,'placed on second reading calendar','president signed','public hearing and executive session scheduled','public hearing in','public hearing scheduled','public hearing','public safety','receded from amendments','reentry','referred to rules'
        ,'referred to','rehabilitation','reintroduced and retained','relieved of further consideration','returned to house rules committee','returned to rules committee','returned to senate','returned to','rules 2 consideration','rules 3','rules committee'
        ,'rules','rural development','second reading','secretary of state','senate amendments','senate committee','senate rules','state government tribal relations','state government tribal relations elections','third reading','to be reported out of committee'
        ,'trade','transportation','veterans','ways means']#'WA'
    ,['3rd reading','action rejected','agriculture and rural development','approved by governor','banking and insurance','bill rejected','by rules committee','chapter','children and families','committed to finance on 2st reading','committed to finance'
        ,'committee tabled','communicated to house','communicated to senate','completed legislative action','discharge rejected','economic development','to education','energy industry and mining','to finance','from table rejected','health','house agriculture and natural resources'
        ,'to house banking and insurance','house calendar','house fire departments and emergency medical services','house industry and labor','house message received','house pensions and retirement','house prevention and treatment of substance abuse','house received senate message'
        ,'house rejected','house rules','house senior children and family issues','house small business entrepreneurship and economic development','house veterans affairs and homeland security','human resources','interstate cooperation','motion house reconsider'
        ,'motion to discharge','natural resources','on 1st reading','on 2nd reading','on 3rd reading','on unfinished business','ordered to house','pensions','placed on house calendar','referred to rules','regular session','rejected by senate','removed from calendar'
        ,'reported by the clerk','reported in com. sub.','rules','senate requests house to concor','take from table motion','to conference','to government organization','to health and human resources','to house agriculture and natural resources','to house education'
        ,'to house finance','to house finance','to house government organization','to house judiciary','to house judiciary','to house political subdivisions','to house technology and infrastructure','to judiciary','to military','to transportation and infrastructure'
        ,'vetoed by governor','workforce','motion to take discharge']#'WV'
    ,['adopted','added as coauthor' ,'by governor' ,'committee on rules','enrolled joint resolution','failed to adopt','failed to concur','failed to pass','fiscal estimated received','governor','in pursuant to','not published','notwithstanding the objections of the governor'
        ,'presented to the governor','published','pursuant to','referred to','refused to pass item veto','refused to pass','report correctly enrolled','report voted by the governor','senate amendment 1 offered','senate joint resolution 1','senator added as a contributor'
        ,'senator cowles added as a contributor','veto message submitted']#'WI'
    ,['3rd reading failed','assigned','chapter number','cow failed','did not consider for COW','did not consider','died in committee','failed introduction','for introductive vote','for introductive','governor signed','governor vetoed','postponed indefinitely'
        ,'withdrawn by sponsor','withdrawn']#'WY'
    ,[]#'DC'
    ,['motion','suspend','amend','approved','report','assigned','consensus','calendar','assuming','first','second','third'
        ,'sponsorship','unanimous','introduce','refer','debate','question','object','quorum','duplicate','engross','became','public','law'
        ,'rules','committee','immediate','consideration','environment','work','oversight','reform','intelligence','filed','armed services','homeland'
        ,'government','energy','natural','resources','written','commerce','science','transportation','house','senate','cloture','present','withdrawn'
        ,'unanimous','consent','concur','not invoked','vote','disagree','bill','proceed','hearing','held','unfinished','business','whole','state','union','agriculture'
        ,'nutrition','forestry','favorabl','appropriations','banking','housing','urban','affairs','commerce','space','transportation','education','labor','water','power'
        ,'national parks','land','forests','mining','works','ethics','financ','services','foreign','','health','administration','indian','pensions','technologu'
        ,'small','business','entrepreneurship','discharge','judiciary','veteran','relations','united','states','ways and means','joint','conference','paper','privilege'
        ,'matter','consider','pursuant','suspension','provision','hour','engross', 'correct','fail','pass','floor','summary','one','two','three','forward','full'
        ,'general','offer','voice','prior','introduction','refer','prior','grant','extension','further','resolve','itself','read','once','twice','without','laid'
        ,'objection','chair','veto','desk','words taken down','speaker','president','appoint','resolution','rose','clerk','authorize','submit','adopt','preamble'
        ,'introductory','remarks','session','indigenous peoples','africa','global','human rights','international','organization','antitrust','commercial','administrative law'
        ,'aviation','asia','pacific','nonproliferation','border','facilitation','operations','coast guard','maritime','communication','courts','intellectual property'
        ,'internet','crime','terrorism','cyber','infrastructure protection','innovation','disability assistance','memorial','economic','development', 'opportunity'
        ,'buildings','emergency management','emergency preparedness','response','recovery','mineral','europe','eurasia','highways','transit','immigration','citizenship'
        ,'counterterrorism','livestock','middle east','railroads','pipelines','hazardous materials','constitution','civil', 'rights', 'liberties','security','oceans'
        ,'wildlife','signed','trade','commodity exchanges','credit','biotechnology','horticulture','conservation','research','farm','commodities','risk','management'
        ,'readiness','seapower','projection','social','aeronautics','strategic forces','tactical air','land forces','western hemisphere','civilian'
        ,'worker','family','support','postpone','conclusion','point of order','place'
            ]#'US'
    ]
,'state_clf': [
     ''#'UK'  #0
    ,'MLPClassifier'#'AL' #1
    ,'MultinomialNB'#'AK' #2
    ,'SGDClassifier'#'AZ' #3
    ,''#'AR' #4
    ,'MLPClassifier'#'CA' #5
    ,''#'CO' #6
    ,''#'CT' #7
    ,'MLPClassifier'#'DE' #8
    ,''#'FL' #9
    ,''#'GA' #10
    ,'MLPClassifier'#'HI' #11
    ,''#'ID' #12
    ,'MultinomialNB'#'IL' #13
    ,''#'IN' #14
    ,''#'IA' #15
    ,''#'KS' #16
    ,''#'KY' #17
    ,''#'LA' #18
    ,''#'ME' #19
    ,''#'MD' #20
    ,'MultinomialNB'#'MA' #21
    ,'MLPClassifier'#'MI' #22
    ,''#'MN' #23
    ,''#'MS' #24
    ,''#'MO' #25
    ,''#'MT' #26
    ,''#'NE' #27
    ,''#'NV' #28
    ,''#'NH' #29
    ,'MLPClassifier'#'NJ' #30
    ,''#'NM' #31
    ,'MultinomialNB'#'NY' #32
    ,''#'NC' #33
    ,''#'ND' #34
    ,'MultinomialNB'#'OH' #35
    ,''#'OK' #36
    ,''#'OR' #37
    ,'MLPClassifier'#'PA' #38
    ,''#'RI' #39
    ,''#'SC' #40
    ,''#'SD' #41
    ,''#'TN' #42
    ,'MLPClassifier'#'TX' #43
    ,''#'UT' #44
    ,''#'VT' #45
    ,''#'VA' #46
    ,''#'WA' #47
    ,''#'WV' #48
    ,'MLPClassifier'#'WI' #49
    ,''#'WY' #50
    ,''#'DC' #51
    ,'MLPClassifier'#'US' #52
    ]

,'state_clf_params':
    [
     {}#'UK'  #0
    ,{          "hidden_layer_sizes": [150,50],
                "activation": "identity",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.0001,
                "tol": 0.001,
                "n_iter_no_change": 4
                }#'AL' #1
    ,{"alpha": 1}#'AK' #2
    ,{          "max_iter": 2000,
                "alpha": 0.0001
                }#'AZ' #3
    ,{}#'AR' #4
    ,{          "hidden_layer_sizes": [50],
                "activation": "relu",
                "max_iter": 100,
                "solver": "adam",
                "alpha": 0.0001,
                "tol": 0.001,
                "n_iter_no_change": 4
                }#'CA' #5
    ,{}#'CO' #6
    ,{}#'CT' #7
    ,{          "hidden_layer_sizes": [50],
                "activation": "logistic",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.0001,
                "tol": 0.001,
                "n_iter_no_change": 4
                }#'DE' #8
    ,{}#'FL' #9
    ,{}#'GA' #10
    ,{          "hidden_layer_sizes": [50],
                "activation": "identity",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.1,
                "tol": 0.001,
                "n_iter_no_change": 4}#'HI' #11
    ,{}#'ID' #12
    ,{"alpha": 1}#'IL' #13
    ,{}#'IN' #14
    ,{}#'IA' #15
    ,{}#'KS' #16
    ,{}#'KY' #17
    ,{}#'LA' #18
    ,{}#'ME' #19
    ,{}#'MD' #20
    ,{'alpha':1}#'MA' #21
    ,{          "hidden_layer_sizes": [50],
                "activation": "identity",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.1,
                "tol": 0.001,
                "n_iter_no_change": 4}#'MI' #22
    ,{}#'MN' #23
    ,{}#'MS' #24
    ,{}#'MO' #25
    ,{}#'MT' #26
    ,{}#'NE' #27
    ,{}#'NV' #28
    ,{}#'NH' #29
    ,{          "hidden_layer_sizes": [50],
                "activation": "identity",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.1,
                "tol": 0.001,
                "n_iter_no_change": 4}#'NJ' #30
    ,{}#'NM' #31
    ,{'alpha':1}#'NY' #32
    ,{}#'NC' #33
    ,{}#'ND' #34
    ,{"alpha": 1}#'OH' #35
    ,{}#'OK' #36
    ,{}#'OR' #37
    ,{          "hidden_layer_sizes": [50],
                "activation": "identity",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.1,
                "tol": 0.001,
                "n_iter_no_change": 4}#'PA' #38
    ,{}#'RI' #39
    ,{}#'SC' #40
    ,{}#'SD' #41
    ,{}#'TN' #42
    ,{          "hidden_layer_sizes": [50],
                "activation": "logistic",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.0001,
                "tol": 0.001,
                "n_iter_no_change": 4}#'TX' #43
    ,{}#'UT' #44
    ,{}#'VT' #45
    ,{}#'VA' #46
    ,{}#'WA' #47
    ,{}#'WV' #48
    ,{          "hidden_layer_sizes": [50],
                "activation": "identity",
                "max_iter": 100,
                "solver": "lbfgs",
                "alpha": 0.1,
                "tol": 0.001,
                "n_iter_no_change": 4}#'WI' #49
    ,{}#'WY' #50
    ,{}#'DC' #51
    ,{ "hidden_layer_sizes": [50],
                "activation": "relu",
                "max_iter": 100,
                "solver": "adam",
                "alpha": 0.0001,
                "tol": 0.001,
                "n_iter_no_change": 4}#'US' #52
    ]

,'state_text_feature_size':[]

,'state_legislative_calendars':
    [
     []#'UK'  #0
    ,{
        
         'Regular Session 2010':[date(2010,1,12),date(2010,4,22)]
        ,'First Special Session 2010':[date(2010,1,12),date(2010,4,22)]
        ,'Regular Session 2011':[date(2011,3,1),date(2011,6,9)]
        ,'Organizational Session 2011':[date(2011,3,1),date(2011,6,9)]
        ,'Regular Session 2012':[date(2012,2,7),date(2012,5,16)]
        ,'First Special Session 2012':[date(2012,2,7),date(2012,5,16)]
        ,'Regular Session 2013':[date(2013,2,5),date(2013,5,20)]
        ,'Regular Session 2014':[date(2014,1,14),date(2014,4,3)]
        ,'Regular Session 2015':[date(2015,3,3),date(2015,6,4)]
        ,'Organizational Session 2015':[date(2015,3,3),date(2015,6,4)]
        ,'First Special Session 2015':[date(2015,3,3),date(2015,6,4)]
        ,'Second Special Session 2015':[date(2015,3,3),date(2015,6,4)]
        ,'Regular Session 2016':[date(2016,2,2),date(2016,5,3)]
        ,'First Special Session 2016':[date(2016,2,2),date(2016,5,3)]
        ,'Regular Session 2017':[date(2017,2,7),date(2017,5,19)]
        ,'Regular Session 2018':[date(2018,1,9),date(2018,3,29)]
        ,'Regular Session 2019':[date(2019,3,5),date(2019,5,31)]
        ,'First Special Session 2019':[date(2019,3,5),date(2019,5,31)]
        ,'Regular Session 2020':[date(2020,2,4),date(2020,5,20)]
        }#'AL' #1
    ,{
         '26th Legislature':[date(2009,1,20),date(2010,4,19)]
        ,'27th Legislature':[date(2011,1,18),date(2012,4,16)]
        ,'28th Legislature':[date(2013,1,15),date(2014,4,25)]
        ,'29th Legislature':[date(2015,1,20),date(2016,5,18)]
        ,'30th Legislature':[date(2017,1,17),date(2018,5,13)]
        ,'31st Legislature':[date(2019,1,15),date(2020,5,19)]
        }#'AK' #2
    ,{
         2009:[]
        ,2010:[]
        ,2011:[]
        ,2012:[]
        ,2013:[]
        ,2014:[]
        ,2015:[]
        ,2016:[]
        ,2017:[]
        ,2018:[]
        ,2019:[]
        ,2020:[]
        }#'AZ' #3
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'AR' #4
    ,{   '2009-2010 Session':[date(2008,12,1),date(2010,11,30)]
        ,'2011-2012 Session':[date(2010,12,6),date(2012,11,30)]
        ,'2013-2014 Regular Session':[date(2012,12,3),date(2014,11,30)]
        ,'2015-2016 Regular Session':[date(2014,12,1),date(2016,11,30)]
        ,'2017-2018 Regular Session':[date(2016,12,5),date(2018,11,30)]
        ,'2019-2020 Regular Session':[date(2018,12,3),date(2020,11,30)]
        }#'CA' #5
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'CO' #6
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'CT' #7
    ,{   '145th General Assembly':[date(2009,1,13),date(2010,6,30)]
        ,'146th General Assembly':[date(2011,1,11),date(2012,6,30)]
        ,'147th General Assembly':[date(2013,1,8),date(2014,7,1)]
        ,'148th General Assembly':[date(2015,1,13),date(2016,7,1)]
        ,'149th General Assembly':[date(2017,1,10),date(2018,6,30)]
        ,'150th General Assembly':[date(2019,1,8),date(2020,6,30)]
        }#'DE' #8
    ,{
         '2010 Regular Session':[date(2010,3,2),date(2010,4,30)]
        ,'2011 Regular Session':[date(2011,3,8),date(2011,5,6)]
        ,'2012 Regular Session':[date(2012,1,10),date(2012,3,9)]
        ,'2013 Regular Session':[date(2013,3,5),date(2013,5,3)]
        ,'2014 Regular Session':[date(2014,3,3),date(2014,5,5)]
        ,'2015 Special Session':[date(2015,3,3),date(2015,5,1)]
        ,'2016 Regular Session':[date(2016,1,12),date(2016,3,11)]
        ,'2017 Regular Session':[date(2017,3,7),date(2017,5,8)]
        ,'2018 Regular Session':[date(2018,1,9),date(2018,3,11)]
        ,'2019 Regular Session':[date(2019,3,5),date(2019,5,3)]
        ,'2020 Regular Session':[date(2020,1,14),date(2020,3,19)]
        }#'FL' #9
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'GA' #10
    ,{
         '2010 Regular Session':[date(2010,1,2),date(2010,4,29)]
        ,'2011 Regular Session':[date(2011,1,2),date(2011,5,5)]
        ,'2012 Regular Session':[date(2012,1,2),date(2012,5,3)]
        ,'2013 Regular Session':[date(2013,1,2),date(2013,5,2)]
        ,'2014 Regular Session':[date(2014,1,2),date(2014,5,1)]
        ,'2014 1st Special Session':[date(2014,1,2),date(2014,5,1)]
        ,'2015 Regular Session':[date(2015,1,2),date(2015,5,7)]
        ,'2015 1st Special Session':[date(2015,1,2),date(2015,5,7)]
        ,'2016 Regular Session':[date(2016,1,2),date(2016,5,5)]
        ,'2016 1st Special Session':[date(2016,1,2),date(2016,5,5)]
        ,'2016 2nd Special Session':[date(2016,1,2),date(2016,5,5)]
        ,'2017 Regular Session':[date(2017,1,2),date(2017,5,30)]
        ,'2017 1st Special Session':[date(2017,1,2),date(2017,5,30)]
        ,'2017 2nd Special Session':[date(2017,1,2),date(2017,5,30)]
        ,'2018 Regular Session':[date(2018,1,2),date(2018,5,4)]
        ,'2018 1st Special Session':[date(2018,1,2),date(2018,5,4)]
        ,'2019 Regular Session':[date(2019,1,2),date(2019,5,2)]
        ,'2020 Regular Session':[date(2020,1,2),date(2020,5,7)]
        }#'HI' #11
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'ID' #12
    ,{
         '96th General Assembly':[date(2009,1,14),date(2010,5,7)]
        ,'97th General Assembly':[date(2011,1,12),date(2012,5,31)]
        ,'98th General Assembly':[date(2013,1,9),date(2014,6,2)]
        ,'99th General Assembly':[date(2015,1,14),date(2016,5,31)]
        ,'100th General Assembly':[date(2017,1,11),date(2018,5,31)]
        ,'101st General Assembly':[date(2019,1,9),date(2010,5,23)]
        }#'IL' #13
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'IN' #14
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'IA' #15
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'KS' #16
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'KY' #17
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'LA' #18
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'ME' #19
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'MD' #20
    ,{
         '186th General Court':[date(2009,1,7),date(2010,7,31)]
        ,'187th General Court':[date(2011,1,5),date(2012,7,31)]
        ,'188th General Court':[date(2013,1,2),date(2014,7,31)]
        ,'189th General Court':[date(2015,1,7),date(2016,7,31)]
        ,'190th General Court':[date(2017,1,4),date(2018,7,31)]
        ,'191st General Court':[date(2019,1,2),date(2020,7,31)]
        }#'MA' #21
    ,{
         '95th Legislature':[date(2009,1,14),date(2010,12,31)]
        ,'96th Legislature':[date(2011,1,12),date(2012,12,31)]
        ,'97th Legislature':[date(2013,1,9),date(2014,12,31)]
        ,'98th Legislature':[date(2015,1,14),date(2016,12,31)]
        ,'99th Legislature':[date(2017,1,11),date(2018,12,31)]
        ,'100th Legislature':[date(2019,1,9),date(2020,12,31)]
        }#'MI' #22
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'MN' #23
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'MS' #24
    ,{
         '2010 Regular Session':[date(2010,1,13),date(2010,5,31)]
        ,'2010 1st Special Session':[date(2010,1,13),date(2010,12,31)]
        ,'2010 Extraordinary Session':[date(2010,1,7),date(2010,12,31)]
        ,'2011 Regular Session':[date(2011,1,7),date(2011,5,31)]
        ,'2011 1st Special Session':[date(2011,1,7),date(2011,12,31)]
        ,'2011 Extraordinary Session':[date(2011,1,7),date(2011,12,31)]
        ,'2012 Regular Session':[date(2012,1,7),date(2012,5,31)]
        ,'2013 Regular Session':[date(2013,1,7),date(2013,5,31)]
        ,'2013 1st Special Session':[date(2013,1,7),date(2013,12,31)]
        ,'2014 Regular Session':[date(2014,1,7),date(2014,5,31)]
        ,'2015 Regular Session':[date(2015,1,7),date(2015,5,31)]
        ,'2016 Regular Session':[date(2016,1,7),date(2016,5,31)]
        ,'2017 Regular Session':[date(2017,1,7),date(2017,5,31)]
        ,'2017 1st Special Session':[date(2017,1,7),date(2017,12,31)]
        ,'2017 2nd Special Session':[date(2017,1,7),date(2017,12,31)]
        ,'2017 1st Extraordinary Session':[date(2017,1,8),date(2017,12,31)]
        ,'2017 2nd Extraordinary Session':[date(2017,1,8),date(2017,12,31)]
        ,'2018 Regular Session':[date(2018,1,3),date(2018,5,31)]
        ,'2018 1st Special Session':[date(2018,1,3),date(2018,12,31)]
        ,'2018 2nd Special Session':[date(2018,1,3),date(2018,12,31)]
        ,'2018 1st Extraordinary Session':[date(2018,1,8),date(2018,12,31)]
        ,'2018 2nd Extraordinary Session':[date(2018,1,8),date(2018,12,31)]
        ,'2019 Regular Session':[date(2019,1,9),date(2019,5,31)]
        ,'2019 1st Extraordinary Session':[date(2019,1,8),date(2019,12,31)]
        ,'2020 Regular Session':[date(2020,1,8),date(2020,5,31)]
        ,'2020 1st Extraordinary Session':[date(2020,1,8),date(2020,12,31)]
        }#'MO' #25
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'MT' #26
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'NE' #27
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'NV' #28
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'NH' #29
    ,{
         '2010-2011 Regular Session':[date(2010,1,12),date(2012,1,9)]
        ,'2012-2013 Regular Session':[date(2012,1,10),date(2014,1,13)]
        ,'2014-2015 Regular Session':[date(2014,1,14),date(2016,1,11)]
        ,'2016-2017 Regular Session':[date(2016,1,12),date(2018,1,8)]
        ,'2018-2019 Regular Session':[date(2018,1,9),date(2020,1,13)]
        ,'2020-2021 Regular Session':[date(2020,1,14),date(2020,12,31)]
        }#'NJ' #30
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'NM' #31
    ,{   '2009 General Assembly'     :[date(2009,1,7),date(2010,12,31)]
        ,'2011-2012 General Assembly':[date(2011,1,5),date(2012,6,22)]
        ,'2013-2014 General Assembly':[date(2013,1,9),date(2014,6,22)]
        ,'2015-2016 General Assembly':[date(2015,1,7),date(2016,6,18)]
        ,'2017-2018 General Assembly':[date(2017,1,4),date(2018,6,20)]
        ,'2019-2020 General Assembly':[date(2019,1,9),date(2020,6,2)]
        }#'NY' #32
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'NC' #33
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'ND' #34
    ,{
         '128th General Assembly (2009-2010)':[date(2009,1,5),date(2010,12,31)]
        ,'129th General Assembly (2011-2012)':[date(2011,1,3),date(2012,12,31)]
        ,'130th General Assembly':[date(2013,1,7),date(2014,12,31)]
        ,'131st General Assembly':[date(2015,1,5),date(2016,12,31)]
        ,'132nd General Assembly':[date(2017,1,2),date(2018,12,31)]
        ,'133rd General Assembly':[date(2019,1,7),date(2012,12,31)]
        }#'OH' #35
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'OK' #36
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'OR' #37
    ,{
         '2009-2010 Regular Session':[date(2009,1,6),date(2010,11,30)]
         ,'2009-2010 Special Session #1 (Transportation)':[date(2009,1,6),date(2010,11,30)]
        ,'2011-2012 Regular Session':[date(2011,1,4),date(2012,11,30)]
        ,'2013-2014 Regular Session':[date(2013,1,1),date(2014,11,30)]
        ,'2015-2016 Regular Session':[date(2015,1,6),date(2016,11,30)]
        ,'2017-2018 Regular Session':[date(2017,1,3),date(2018,11,30)]
        ,'2019-2020 Regular Session':[date(2019,1,1),date(2020,11,30)]
        }#'PA' #38
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'RI' #39
    ,{  
         '118th General Assembly':[date(2009,1,1),date(2010,6,30)]
        ,'119th General Assembly':[date(2011,1,1),date(2012,6,30)]
        ,'120th General Assembly':[date(2013,1,1),date(2014,6,30)]
        ,'121st General Assembly':[date(2015,1,1),date(2016,6,30)]
        ,'122nd General Assembly':[date(2017,1,1),date(2018,6,30)]
        ,'123rd General Assembly':[date(2019,1,1),date(2020,6,30)]
        }#'SC' #40
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'SD' #41
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'TN' #42
    ,{
         '81st Legislature Regular Session':[date(2009,1,13),date(2009,6,1)]
        ,'82nd Legislature Regular Session':[date(2011,1,11),date(2011,5,30)]
        ,'83rd Legislature Regular Session':[date(2013,1,8),date(2013,5,27)]
        ,'84th Legislature Regular Session':[date(2015,1,13),date(2015,6,1)]
        ,'85th Legislature Regular Session':[date(2017,1,10),date(2017,5,29)]
        ,'86th Legislature Regular Session':[date(2019,1,8),date(2019,5,27)]
        }#'TX' #43
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'UT' #44
    ,{    
         '2009-2010 Session':[date(2009,1,1),date(2010,5,30)]
        ,'2011-2012 Session':[date(2011,1,1),date(2012,5,30)]
        ,'2013-2014 Session':[date(2013,1,1),date(2014,5,30)]
        ,'2015-2016 Session':[date(2015,1,1),date(2016,5,30)]
        ,'2018 Special Session':[date(2018,1,1),date(2018,5,30)]
        ,'2017-2018 Session':[date(2017,1,1),date(2018,5,30)]
        ,'2019-2020 Session':[date(2019,1,1),date(2020,5,30)]
        }#'VT' #45
    ,{   
         '2010 Regular Session':[date(2010,1,13),date(2010,3,31)]
        ,'2010 Special I':[date(2010,1,13),date(2010,12,31)]
        ,'2011 Regular Session':[date(2011,1,7),date(2011,3,31)]
        ,'2011 Special I':[date(2011,1,7),date(2011,12,31)]
        ,'2012 Regular Session':[date(2012,1,7),date(2012,3,31)]
        ,'2013 Regular Session':[date(2013,1,7),date(2013,3,31)]
        ,'2013 Special I':[date(2013,1,7),date(2013,12,31)]
        ,'2014 Special I':[date(2014,1,7),date(2014,12,31)]
        ,'2014 Regular Session':[date(2014,1,7),date(2014,3,31)]
        ,'2015 Regular Session':[date(2015,1,7),date(2015,3,31)]
        ,'2015 Special I':[date(2015,1,7),date(2015,12,31)]
        ,'2016 Regular Session':[date(2016,1,7),date(2016,3,31)]
        ,'2017 Regular Session':[date(2017,1,7),date(2017,3,31)]
        ,'2017 Special I':[date(2017,1,7),date(2017,12,31)]
        ,'2017 Special II':[date(2017,1,7),date(2017,12,31)]
        ,'2018 Regular Session':[date(2018,1,3),date(2018,3,31)]
        ,'2018 Special I':[date(2018,1,3),date(2018,12,31)]
        ,'2018 Special II':[date(2018,1,3),date(2018,12,31)]
        ,'2019 Regular Session':[date(2019,1,9),date(2019,3,31)]
        ,'2019 Special I':[date(2019,1,3),date(2019,12,31)]
        ,'2020 Regular Session':[date(2020,1,8),date(2020,3,31)]
        ,'2020 Special I':[date(2020,1,8),date(2020,12,31)]
        }#'VA' #46
    ,{
         '2009-2010 Regular Session':[]
        ,'2011-2012 Regular Session':[]
        ,'2013-2014 Regular Session':[]
        ,'2015-2016 Regular Session':[]
        ,'2017-2018 Regular Session':[]
        ,'2019-2020 Regular Session':[]
        }#'WA' #47
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'WV' #48
    ,{
         '2009-2010 Regular Session':[date(2009,1,13),date(2010,12,31)]
        ,'Dec 2009 Special Session':[date(2009,12,1),date(2009,12,31)]
        ,'June 2009 Special Session':[date(2009,6,1),date(2009,6,30)]
        ,'2011-2012 Regular Session':[date(2011,1,11),date(2012,12,31)]
        ,'Sept 2011 Special Session':[date(2011,9,1),date(2011,9,30)]
        ,'Jan 2011 Special Session':[date(2011,1,1),date(2011,1,31)]
        ,'2013-2014 Regular Session':[date(2013,1,7),date(2014,12,31)]
        ,'Oct 2013 Special Session':[date(2013,10,1),date(2013,10,31)]
        ,'Dec 2013 Special Session':[date(2013,12,1),date(2013,12,31)]
        ,'Jan 2014 Special Session':[date(2014,1,1),date(2014,1,31)]
        ,'2015-2016 Regular Session':[date(2015,1,5),date(2016,12,31)]
        ,'2015 1st Special Session':[date(2015,1,5),date(2015,12,31)]
        ,'2017-2018 Regular Session':[date(2017,1,3),date(2018,12,31)]
        ,'January 2017 Special Session':[date(2017,1,1),date(2017,1,31)]
        ,'August 2017 Special Session':[date(2017,1,3),date(2017,12,31)]
        ,'January 2018 Special Session':[date(2017,1,1),date(2018,1,31)]
        ,'March 2018 Special Session':[date(2018,3,1),date(2018,3,31)]
        ,'2019-2020 Regular Session':[date(2019,1,7),date(2020,12,31)]
        }#'WI' #49
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'WY' #50
    ,{2009:[],2010:[],2011:[],2012:[],2013:[],2014:[],2015:[],2016:[],2017:[],2018:[],2019:[],2020:[]}#'DC' #51
    ,{
         '111th Congress':[date(2009,1,6),date(2010,12,22)]
        ,'112th Congress':[date(2011,1,5),date(2013,1,2)]
        ,'113th Congress':[date(2013,1,3),date(2014,12,16)]
        ,'114th Congress':[date(2015,1,6),date(2017,1,2)]
        ,'115th Congress':[date(2017,1,3),date(2019,1,2)]
        ,'116th Congress':[date(2019,1,3),date(2020,12,31)]}#'US' #52
    ]


}




with open(path.join(data_file_location, 'state_info.dict'), 'wb') as f:
    pickle.dump(state_dict, f)