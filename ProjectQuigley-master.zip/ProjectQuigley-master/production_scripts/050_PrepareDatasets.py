import pickle
import string
import pandas as pd
import dateutil
from datetime import date
import re
from datetime import datetime
import sys
from os import path

#****Function Definitions**********************************************************************************************************

def remove(value, deletechars):
    for c in deletechars:
        value = value.replace(c,'')
    return value

#reduces the event description on a bill into the key words and phrases
#defined in the classifier words list
def simplify_bill_event(bill_event, classifier_keywords):
    temp_stat = []
    for k in status_keywords:
        pos = s.find(k)
        if pos != -1:
            temp_stat.append([k,pos])
    temp_stat.sort(key=lambda x: x[1])
    simplified_event = ' '.join(item[0] for item in temp_stat)
    if simplified_event == '':
        simplified_event = 'unknown'
    return simplified_event

def replace(string, replace_this, with_this):
    new_string = string.split()
    for i, word in enumerate(string.split()):
        if word == replace_this:
            new_string[i] = with_this
    return " ".join(new_string)


def get_committee(first_action):
    first_action = first_action.split()
    committee = "None"
    for i, word in enumerate(first_action):
        if (first_action[i].lower()=="to" and first_action[i-1].lower()=="referred") or first_action[i].lower()=="introduced":
            committee = first_action[i+1:i+7]
            committee = " ".join(committee)
            break
    for i,letter in enumerate(committee):
        if letter == ";":
            committee = committee[0:i]
        elif letter == ",":
            committee = committee[0:i]
    committee = replace(committee, '&', 'and')
    return committee

#********************************************************************************************************************************************************    

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

#the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('running', state_gov_nm, year_to_process, state_id)

#define file names for the inpout and output
_raw_bill_metadata = path.join(data_file_location,  state_gov_nm + year_to_process + 'raw_bill_metadata.list')
_WinList = path.join(data_file_location, state_gov_nm + year_to_process + 'WinList.list')
_StateTargetList = path.join(data_file_location, state_gov_nm + year_to_process + 'StateTargetList.list')
_LegOverallData_CSV = path.join(data_file_location, state_gov_nm + year_to_process + 'LegOverallData.csv')
_LegMetaDataset = path.join(data_file_location, state_gov_nm + year_to_process + 'LegMetaData.df')

#load the raw bill metadata
with open(_raw_bill_metadata,'rb') as f:
    bill_data = pickle.load(f)

#assign the status and passing keywords
status_keywords = state_info['states_event_keywords'][state_id]
passing_keywords = state_info['states_win_keywords'][state_id]

required_length = len(bill_data)

#define the lists that will make up the dictionary loaded into pandas---------------
bill_id_list = [] #keep
time_t_list = [] #keep
previous_hist_list = [[]]
hist_list = [[]] #keep
next_hist_list = [[]] #keep
event_list = [] #keep
previous_event_list = []
next_event_list=[] #keep, is target
sponsor_list = [] #keep
sponsor_vec_list = []
sponsor_vec2=[]
bill_category_list =[]
event_out_desc_list = []
event_out_metric_list = []
doc_id_list = []
year_list = [] #keep
session_list = [] #keep
chamber_list = [] #keep
win_state_list=[] #keep
overall_passed_list=[] #keep, is target
public_sentiment=[] #unused, maybe eventually
public_knowledge=[] #unused, maybe eventually
year_start=[]
status_list=[]
passed_list = []

#add the features from bill_features.ipynb too
title_list = []
proposed_chamber_list = []
primary_name_list = []
primary_id_list = []
primary_party_list = []
number_sponsors_list = []
committee_introduced_list = []
month_introduced_list = []

#newest features
bill_type_list = [] #e.g. "CA", constitutional amendment
numeric_date_list = [] #year+((month-1)/12)+((day-1)/31)
intro_to_end_of_session = []
last_event_to_end_of_session = []

#Grab the lists
for b in bill_data:
    #assign temporary value for everything
    temp_previous_hist_list=[]
    temp_hist_list=[]
    temp_next_hist_list = []
    bill_temp = b['bill_id']
    year_temp = b['session']['year_end']
    session_id_temp = b['session']['session_id']
    session_name = b['session']['session_name']
    session_start = state_info['state_legislative_calendars'][state_id][session_name][0]
    session_end = state_info['state_legislative_calendars'][state_id][session_name][1]
    year_start_temp = b['session']['year_start']
    status_temp = b['status']
    title_temp = b['title']
    proposed_chamber_temp = str(b['body'])
    try:
        primary_id_temp = b['sponsors'][0]['people_id']
        primary_name_temp = b['sponsors'][0]['name']
        primary_party_temp = b['sponsors'][0]['party']
    except:
        primary_id_temp = 'None'
        primary_name_temp = 'None'
        primary_party_temp = 'None'   

    number_sponsors_temp = len(b['sponsors'])
    try:
        committee_introduced_temp = get_committee(b['history'][0]['action'])
    except:
        committee_introduced_temp = 'None'

    #if this represents the date the bill was introduced, it needs to be fixed as the bill status date
    #is for the latest action, not the first
    try:
        bill_time_stamp = str(b['history'][0]['date'])
    except:
        bill_time_stamp = 'None'

    if bill_time_stamp == 'None':
        #year_temp = -1
        month_introduced_temp = -1
        numeric_day_temp = -1
        intro_to_end_of_sessions_temp = -1

    else:
        try:
            _time = datetime.strptime(bill_time_stamp, "%Y-%m-%d")
            #year_temp = _time.strftime("%Y")
            month_introduced_temp = _time.strftime("%m")
            day = _time.strftime("%d")
            numeric_day_temp = float(year_temp) + (float(month_introduced_temp)-1)/12 + (float(day)-1)/(31*12)
            intro_to_end_of_session_temp = (session_end - _time.date()).days/float((session_end - session_start).days)
        except:
            year_temp = -1
            month_introduced_temp = -1
            numeric_day_temp = -1
            intro_to_end_of_session_temp = -1

        #intro_to_end_of_session_temp = (session_end - _time.date()).days/float((session_end - session_start).days)



    #repeat this for the last event on the bill
    try:
        bill_time_stamp = str(b['history'][-1]['date'])
    except:
        bill_time_stamp = 'None'
    
    if bill_time_stamp == 'None':
        last_event_to_end_of_session_temp = -1
    else:
        try:
            _time = datetime.strptime(bill_time_stamp, "%Y-%m-%d")
            last_event_to_end_of_session_temp = (session_end - _time.date()).days/float((session_end - session_start).days)
        except:
            last_event_to_end_of_session_temp = -1

    bill_type_temp = b['bill_type']


    #as time, t, is based on the events that occur on a bill, the lists will include duplicates, as necessary, that align to the number of t instances
    for i,h in enumerate(b['history'],start=1):
        #the history of events is just the current entry
        temp_hist_list.append(remove(str(h['action']).lower(),'\/:*?"<>|0123456789.'))
        
        if i !=1:
            #print(i)
            prev_event = b['history'][i-2]
            #since i is always 1 ahead of the current state, subtract 2 to get the previous step
        else:
            prev_event = b['history']

        temp_previous_hist_list.append(remove(str(prev_event).lower(),'\/:*?"<>|0123456789.'))

        #if the current chamber of the action is blank, use the proposed chamber
        if str(h['chamber']) != '':
            chamber_list.append(str(h['chamber']))
        else:
            chamber_list.append(str(b['body']))
        
        time_t_list.append(i) 
        bill_id_list.append(bill_temp)
        year_list.append(year_temp)
        session_list.append(session_id_temp)
        year_start.append(year_start_temp)

        #labels for passing
        status_list.append(status_temp)
        if status_temp in [4,5]:
            passed_list.append(1)
        else:
            passed_list.append(0)

        #new features here
        title_list.append(title_temp)
        proposed_chamber_list.append(proposed_chamber_temp)
        primary_name_list.append(primary_name_temp)
        primary_id_list.append(primary_id_temp)
        primary_party_list.append(primary_party_temp)
        number_sponsors_list.append(number_sponsors_temp)
        committee_introduced_list.append(committee_introduced_temp)
        month_introduced_list.append(month_introduced_temp)
        
        #newest features
        bill_type_list.append(bill_type_temp)
        numeric_date_list.append(numeric_day_temp)
        
        if intro_to_end_of_session_temp > 0:
            intro_to_end_of_session.append(intro_to_end_of_session_temp)
        else:
            intro_to_end_of_session.append(0)
        if last_event_to_end_of_session_temp > 0:
            last_event_to_end_of_session.append(last_event_to_end_of_session_temp)
        else:
            last_event_to_end_of_session.append(0)

        sponsor_vector = 0.0000
        total_sponsors = 0.0
        
        #grab the next event, which is our label for the MN_NB
        try:
            next_event = b['history'][i]
        except:
            next_event = h
    
        temp_next_hist_list.append(remove(str(next_event['action']).lower(),'\/:*?"<>|0123456789.'))

        for x in b['sponsors']: #this should probably go outside above the previous for loop, but I don't want to break anything
            if x['party'] == 'D':
                sponsor_vector+=0
            elif x['party'] == 'R':
                sponsor_vector+=1
            total_sponsors += 1
        if total_sponsors == 0:
            sponsor_list.append(0.5)
        else:
            sponsor_list.append(sponsor_vector/total_sponsors)   
    #---------------------------------------------------------------------------------------------------------    
        #grab the associated doc_ids to pull in the cluster information
        #use the date of the bill revisions to determine
    #---------------------------------------------------------------------------------------------------------
        if len(b['texts']) == 0:
            doc_id_list.append(0)
            len(b['texts'])
        else:
            for j,d in enumerate(b['texts']):

                doc_date_str = d['date']

                #determine the next date in the list to create a date range to
                #check for
                try:
                    next_doc = b['texts'][j+1]
                    doc_next_date = dateutil.parser.isoparse((next_doc['date'])).date()

                except:
                    doc_next_date = date(2100,1,1)

                hist_date_string = h['date']
                
                #print(hist_date_string)
                
                try:
                    hist_date = dateutil.parser.isoparse(hist_date_string).date()
                except:
                    hist_date = dateutil.parser.isoparse('2000-01-01').date()

                #print(hist_date)
                
                if doc_date_str == '0000-00-00':
                    doc_date = date(2000,1,1)
                else:
                    doc_date = dateutil.parser.isoparse(doc_date_str).date()
                #print(doc_date)
                if hist_date >= doc_date and hist_date < doc_next_date:
                    doc_id_list.append(d['doc_id'])
                #else:
                    #print('doc date:',doc_date,'next doc date:',doc_next_date,'hist date:',hist_date)
                    #doc_id_list.append(d['doc_id'])
    

    #---------------------------------------------------------------------------------------------------------
    previous_hist_list.append(temp_previous_hist_list)
    hist_list.append(temp_hist_list)
    next_hist_list.append(temp_next_hist_list)

#print(len(previous_event_list),len(hist_list),len(next_hist_list))

#process the hist_list to create the simplified event list (use keywords to simplify event descriptions)
#uses the UDF
event_list = []
next_event_list = []
previous_event_list = []
print('doc_id:',len(doc_id_list))
print('bill_id:',len(bill_id_list))

for h in hist_list:
    for s in h:
        event_list.append(simplify_bill_event(s,status_keywords))
for h in next_hist_list:
    for s in h:
        next_event_list.append(simplify_bill_event(s,status_keywords))
for h in previous_hist_list:
    for s in h:
        previous_event_list.append(simplify_bill_event(s,status_keywords))

leg_dict = {'bill_id':bill_id_list
            ,'numeric_date':numeric_date_list
            ,'time_t':time_t_list
            ,'event':event_list
            ,'sponsor_vec':sponsor_list
            ,'session':session_list
            ,'year':year_list
            ,'chamber':chamber_list
            ,'bill_type':bill_type_list
            ,'title':title_list
            ,'proposed_chamber':proposed_chamber_list
            ,'primary_name':primary_name_list
            ,'primary_id':primary_id_list
            ,'primary_party':primary_party_list
            ,'number_sponsors':number_sponsors_list
            ,'committee_introduced':committee_introduced_list
            ,'month_introduced':month_introduced_list
            ,'year_start':year_start
            ,'intro_to_end_of_session':intro_to_end_of_session
            ,'last_event_to_end_of_session':last_event_to_end_of_session
            #,'doc_id':doc_id_list
            ,'previous_event':previous_event_list
            ,'next_event':next_event_list
            ,'passed':passed_list}

#Define the win state
#win_state_list=[]
#bill_id=[]
#x=0
#for b in leg_dict['event']:
#    if b in passing_keywords:
#        x+=1
#        win_state_list.append(1)
#        bill_id.append(leg_dict['bill_id'])
#    else:   
#        win_state_list.append(0)
#print(x)

#Define a variable which has 1 at any time stage to use for overall model
#might want to change this?
#temp_var=[0]*len(bill_id_list)
#current_bill = 1
#cur_id = bill_id_list[0]

#for y in range(0, len(bill_id_list)): 
#    if cur_id == bill_id_list[y]:
#        temp_var[y] = current_bill
#    else:
#        current_bill = current_bill + 1   
#        temp_var[y] = current_bill      
#    cur_id = bill_id_list[y] 
#print(temp_var[len(temp_var)-2])


#overall_passed_list = [0]*len(bill_id_list)

#for x in range(len(temp_var)-2,-1,-1):
#    if status_list[x] in [4,5]:
#        overall_passed_list[x] = 1
#    else:
#        overall_passed_list[x] = 0

#event_target = next_event_list #what we will try to predict when predicting the next state

#output everything
#with open(_WinList,'wb') as f:
#    pickle.dump(overall_passed_list, f)

#with open(_StateTargetList,'wb') as f:
#    pickle.dump(event_target, f)

#create a dataframe and output a dataframe bianry and csv
overall_leg_DF = pd.DataFrame(leg_dict)    

#dataframe output
with open(_LegMetaDataset,'wb') as f:
    pickle.dump(overall_leg_DF, f)

print(overall_leg_DF.dtypes)

#csv output
overall_leg_DF.to_csv(_LegOverallData_CSV)
