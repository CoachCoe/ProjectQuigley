import pandas as pd
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk import FreqDist
from nltk.tag import pos_tag
from nltk.stem import PorterStemmer
import string
import pickle
from os import path
import sys

# I set these manually for testing
state_gov_nm = "CA" # sys.argv[1]
year_to_process = 2019 # sys.argv[2]
data_file_location = "C:\\quigley\\vmdata" # sys.argv[3]

_corpus = path.join(data_file_location, f'{state_gov_nm}{year_to_process - 1}legtext.corpus')
_sectorassignments = path.join(data_file_location, f'{state_gov_nm}{year_to_process}BillSectorAssignments.csv')
_sectorkeywords = path.join(data_file_location, 'sector_keywords.csv')

_billtextstemmed = path.join(data_file_location, f'{state_gov_nm}{year_to_process}billtextprepped_SA.DF')
_sectorkeywordsstemmed = path.join(data_file_location, f'{state_gov_nm}{year_to_process}SPsector.DF')
_rawBillMetadata = path.join(data_file_location, f"{state_gov_nm}{year_to_process - 1}raw_bill_metadata.list")

ps = PorterStemmer()

billdesc_words_list = []
sectordesc_words_list = []

#define words to remove and stop words
removestrings = ['a','b','c','d','e','f','g','h','i','j',\
                    'k','l','m','n','o','p','q','r','s','t',\
                    'u','v','w','x','y','z']

stop_words = set(stopwords.words('english'))

print('Loading Files')
with open(_corpus,'rb') as f:
    billdescLS = pickle.load(f)

with open(_rawBillMetadata,'rb') as f:
    billMetadata = pickle.load(f)

billMetadataDF = pd.DataFrame(billMetadata).loc[:, ['bill_id', 'title', 'description', 'url']]
billMetadataDF = billMetadataDF.set_index(keys='bill_id')

billdescDF = pd.DataFrame(billdescLS,columns=['bill_id','doc_id','billtext','mime'])
#print(billdescDF.head())

#import sector description csv file as pandas dataframe
SPsectorDF = pd.read_csv(_sectorkeywords)

billText_list = billdescDF['billtext'].tolist()

print('Preparing Corpus')
for billText in billText_list:
    try:
        wordsinDesc = [ps.stem(w) for w in billText]
    except Exception as e:
        print(e)
        wordsinDesc = []
        
    billdesc_words_list.append(wordsinDesc)

billdescDF['billtextRaw'] = billText_list
billdescDF['billtext'] = billdesc_words_list

secdesc_list = SPsectorDF['subsector_keywords'].tolist()

wordsinDesc = []

print('Preparing Sector Keywords')
for secText in secdesc_list:

    secText = secText.replace('\n',' ').replace('\t',' ')
    tokens = word_tokenize(secText)

    tokens = [w.lower() for w in tokens]

    table = str.maketrans('', '', string.punctuation)
    strippedsecText = [w.translate(table) for w in tokens]

    wordsinDesc = [word for word in strippedsecText if word.isalpha()]

    wordsinDesc = [w for w in wordsinDesc if not w in stop_words]
    wordsinDesc = [w for w in wordsinDesc if not w in removestrings]
    try:
        wordsinDesc = [ps.stem(w) for w in wordsinDesc]
        #x += 1
    except:
        wordsinDesc = []

    sectordesc_words_list.append(wordsinDesc)

SPsectorDF['desc_words'] = sectordesc_words_list

print('Saving Prepared Files')
with open(_billtextstemmed, 'wb') as f:
    pickle.dump(billdescDF, f)

with open(_sectorkeywordsstemmed, 'wb') as f:
    pickle.dump(SPsectorDF, f)

sector_id_list = SPsectorDF['subsector_id']

print('Assigning Sectors')
#SimpleVersion------------------------------------------
#check for any keywords that match
sector_match = [None]*len(billdesc_words_list)

#f = open(path.join(data_file_location,'log.txt'),'w')

sector_match_description = [None]*len(billdesc_words_list)
sector_match_name = [None]*len(billdesc_words_list)

for i,b in enumerate(billdesc_words_list):
    previous_sector_match_count = 0
    sector_match_count = 0
    #print('Doc text is:',b, file=f)
    for j,se in enumerate(sectordesc_words_list):
        #print('Sector keywords are:',se, file=f)
        # this line is the 2nd big fix, resetting the count of matches for each sector
        sector_match_count = 0
        for s in se:
            keyword_match_count = b.count(s)
            if keyword_match_count > 0:
         #       print(s, 'has a match of ', keyword_match_count,file=f)
                sector_match_count+=keyword_match_count
        if previous_sector_match_count < sector_match_count:
            #print(i,j,sector_id_list[j])
            sector_match[i]=sector_id_list[j]
            sector_match_description[i]=SPsectorDF.at[j, "subsector_keywords"].replace("\n", ", ")
            sector_match_name[i]=SPsectorDF.at[j, "subsector_name"]
            previous_sector_match_count = sector_match_count
    if previous_sector_match_count == 0:
        sector_match[i] = sector_id_list[(len(sector_id_list) - 1)]
        sector_match_description[i]=SPsectorDF.at[(len(sector_id_list) - 1), "subsector_keywords"].replace("\n", ", ")
        sector_match_name[i]=SPsectorDF.at[(len(sector_id_list) - 1), "subsector_name"]
#print(sector_match[0:15],len(sector_match))
#f.close()

bill_names = []
bill_desc = []
for i, row in billdescDF.iterrows():
    bill_desc.append(billMetadataDF.at[row['bill_id'], 'description'])
    bill_names.append(billMetadataDF.at[row['bill_id'], 'title'])

billdescDF['subsector_id'] = sector_match
billdescDF['subsector_name'] = sector_match_name
billdescDF['subsector_keywords'] = sector_match_description
billdescDF['bill_title'] = bill_names
billdescDF['bill_description'] = bill_desc
billdescDF = billdescDF.drop_duplicates(subset=['bill_id'], keep="last")

billdescDF_out = billdescDF[['bill_id', 'bill_title', 'bill_description', 'subsector_id', 'subsector_name', 'subsector_keywords']].copy()

billdescDF_out.to_csv(_sectorassignments)

#AdvancedVersion-----------------------------------------
#load in Google word2vec



#Get list of word embeddings for each row



#kmeans cluster for each document




#look for overlaps of the radius of each cluster