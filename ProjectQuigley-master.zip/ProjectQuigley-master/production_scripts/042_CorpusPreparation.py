import sys
import pickle
import html2text as h2t
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.tag import pos_tag
import string
import io
from tika import parser
from os import path

try:
    state_gov_nm = sys.argv[1]
    year_to_process = sys.argv[2]
    data_file_location = sys.argv[3]
except:
    print("Missing Data Error: Enter State Abbreviation, Year, And Directory Path ")
    sys.exit()

failed = []

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

# the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('Running', state_gov_nm, year_to_process)

file_in = path.join(data_file_location, state_gov_nm + year_to_process + 'legtext_raw.corpus')
file_out = path.join(data_file_location, state_gov_nm + year_to_process + 'legtext.corpus')
if path.exists(file_in) == False:
    print("Path:", file_in, "Does not exist, check for valid data entry")
    sys.exit()

textLinetoStartAfter = ''
usetextLinetoStartAfter = False

print('Loading corpus file')
with open(file_in, 'rb') as f:
    legtext_corpus = pickle.load(f)

try:
    for ind, document in enumerate(legtext_corpus):
        if ind % 1000 == 0:
            print(ind)

        text = document[2]

        rawbillText = ''

        if document[3] == 'text/html':
            try:
                rawbillText = h2t.html2text(text)
            except:
                failed.append(ind)
                # could also append ((ind, document)) not sure how long document if

        elif document[3] == 'application/pdf':
            try:
                pdftext = io.BytesIO(bytes(text))

                raw = parser.from_buffer(pdftext)
                rawbillText = raw['content']
            except:
                failed.append(ind)
                # same as above could be with document depending on length

        billText = ''

        if usetextLinetoStartAfter:
            i = False
        else:
            i = True
        if rawbillText is not None:
            for l in rawbillText.split('\n'):
                if i:
                    billText = billText + str(l) + ' '
                if textLinetoStartAfter in l:
                    i = True

            tokens = word_tokenize(billText)
            tags = pos_tag(tokens)
            tokens = [w.lower() for w in tokens]

            table = str.maketrans('', '', string.punctuation)
            strippedBillText = [w.translate(table) for w in tokens]

            wordsInBill = [word for word in strippedBillText if word.isalpha()]

            singleCharacters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', \
                                'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', \
                                'u', 'v', 'w', 'x', 'y', 'z']

            stop_words = set(stopwords.words('english'))
            wordsInBill = [w for w in wordsInBill if not w in stop_words]
            wordsInBill = [w for w in wordsInBill if not w in singleCharacters]

            legtext_corpus[ind][2] = wordsInBill
except Exception as e:
    print("Error: ", e)

with open(file_out, 'wb') as f:
    pickle.dump(legtext_corpus, f)

# error File
with open("Error_File.txt", "a") as f:
    for item in failed:
        f.write(item)