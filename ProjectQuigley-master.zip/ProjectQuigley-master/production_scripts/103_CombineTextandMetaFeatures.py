import pickle
import numpy as np
import pandas as pd
import nltk
from nltk.stem.snowball import SnowballStemmer
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfTransformer

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2, f_classif, mutual_info_classif

from pprint import pprint
from time import time
import logging

import warnings
from sklearn.metrics import classification_report
from sklearn.exceptions import ConvergenceWarning
warnings.simplefilter("ignore", ConvergenceWarning)
import sys
from os import path

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

with open(path.join(data_file_location, 'state_info.dict'), 'rb') as f:
    state_info = pickle.load(f)

#the state id is used to access the proper element in each list within the state dictionary
state_id = state_info['states_abbrev'].index(state_gov_nm)

print('running', state_gov_nm, year_to_process)

#_LegOverallData_Init = path.join(data_file_location, state_gov_nm + year_to_process + 'LegOverallData.csv')

legcorpus = []
win_state = []
leg_data = pd.DataFrame()
#leg_data = leg_data[0:0]

_LegOverAllCLF = path.join(data_file_location, state_gov_nm + year_to_process + 'overall_clf.joblib')
_X = path.join(data_file_location, state_gov_nm + year_to_process + 'predictions.df')
_X_CSV = path.join(data_file_location, state_gov_nm + year_to_process + 'predictions.csv')

_train_meta_features = path.join(data_file_location, state_gov_nm + 'train_meta_features.df')
_test_meta_features = path.join(data_file_location, state_gov_nm + 'test_meta_features.df')
_train_labels = path.join(data_file_location, state_gov_nm + 'train_labels.df')
_test_labels = path.join(data_file_location, state_gov_nm + 'test_labels.df')

_train_text_features = path.join(data_file_location, state_gov_nm + 'train_text_features.np')
_test_text_features = path.join(data_file_location, state_gov_nm + 'test_text_features.np')
_train_features_complete = path.join(data_file_location, state_gov_nm + 'train_features_complete.np')
_test_features_complete = path.join(data_file_location, state_gov_nm + 'test_features_complete.np')

with open(_train_meta_features,'rb') as f:
   X_train = pickle.load(f)

with open(_test_meta_features,'rb') as f:
    X_test = pickle.load(f)

with open(_train_text_features,'rb') as f:
    legtext_train = pickle.load(f)

with open(_test_text_features,'rb') as f:
    legtext_test= pickle.load(f)

X_train = np.concatenate([np.array(X_train),legtext_train], axis=1)
X_test = np.concatenate([np.array(X_test),legtext_test], axis=1)

with open(_train_features_complete,'wb') as f:
    pickle.dump(X_train,f)

with open(_test_features_complete,'wb') as f:
    pickle.dump(X_test,f)

print('Feature Creation Complete')
