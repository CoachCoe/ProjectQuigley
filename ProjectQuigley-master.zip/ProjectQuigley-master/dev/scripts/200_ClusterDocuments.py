#!/usr/bin/env python
# coding: utf-8

# This notebook will perform kmeans clustering on the document embeddings (now a pandas dataframe).  This output will be a simple list of tuples (doc_id and the cluster assigned via kmeans).

# In[19]:


import pickle
import numpy
import pandas as pd
from sklearn.cluster import KMeans
from os import path
from os import listdir
import sys
from azureml.core import Dataset, Workspace
import joblib

vector_size = [32, 64, 96, 128, 160, 192]
cluster_size = [10, 30, 50, 70, 100]

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]
model_file_location = sys.argv[4]

#_embedded_docs = path.join(data_file_location,state_gov_nm + 'embedded_legdoc.df')
#_bill_clusters_csv = path.join(data_file_location,state_gov_nm + v + c + 'BillClusters.csv')
#_bill_clusters = path.join(data_file_location,state_gov_nm + v + c + 'bill_clusters.df')

# In[20]:

#loop through every iteration of vector size and cluster size
for v in vector_size:
    for c in cluster_size:
        #replace with the dataset created from the vector files
        _embedded_docs = path.join(data_file_location,state_gov_nm + str(v) + 'embedded_legdoc.df')
        with open(_embedded_docs,'rb') as f:
            docvecDF = pickle.load(f)
        _bill_clusters_csv = path.join(data_file_location,state_gov_nm + str(v) + str(c) + 'BillClusters.csv')
        _bill_clusters = path.join(data_file_location,state_gov_nm + str(v) + str(c) + 'bill_clusters.df')
        vectors = docvecDF.drop(columns=['bill_id'])
        doc_clusters = KMeans(n_clusters = c)
        doc_labels = doc_clusters.fit_predict(vectors)
        billCats = docvecDF.copy()
        billCats['category'] = doc_labels
        with open(_bill_clusters,'wb') as f:
            pickle.dump(billCats, f)
        billCats.to_csv(_bill_clusters_csv)
        #export the model
        _model = path.join(model_file_location, + state_gov_nm + str(v) + str(c) + '_cluster.sk')
        joblib.dump(doc_clusters, _model)
        

