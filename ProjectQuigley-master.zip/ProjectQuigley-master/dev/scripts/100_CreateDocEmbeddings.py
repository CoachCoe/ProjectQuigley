#!/usr/bin/env python
# coding: utf-8

# This notebook will take the corpus, translate it into a gensim TaggedDocument list, and train the doc2vec model in order to extract the document vecotrs.  We will then translate that into a pandas data frame and save to a file for use in kmeans clustering.

# In[1]:

import pickle
import argparse
import pandas as pd
from os import path, environ,listdir
from azureml.core import Dataset, Workspace
import tempfile
import numpy as np
from pprint import pprint
from gensim.models import Doc2Vec as d2v
from gensim.models.doc2vec import TaggedDocument as td
import joblib
import sys
from azureml.core.authentication import ServicePrincipalAuthentication

vector_size = [32, 64, 96, 128, 160, 192]

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]
model_file_location = sys.argv[4]


# In[2]:


sp = ServicePrincipalAuthentication(tenant_id="26abc6ef-f140-44d3-87ec-94ac09fd36d2", # tenantID
                                    service_principal_id="b7431496-79ec-4906-915d-de3ca0970716", # clientId
                                    service_principal_password=environ.get('MLQUIGSECRET')) # clientSecret

ws = Workspace.get(name="ml-quigley"
                   , subscription_id='8d8bcbfe-86b4-42bb-a470-a8cf97c98d69'
                   , resource_group='project-quigley'
                   , auth=sp
                    )




#local_ds_path = tempfile.mkdtemp(prefix='tmp',dir='txt_dataset')

#define the azureml dataset
leg_text_ds = Dataset.get_by_name(ws,'leg_text_ds')

#_embeddings = path.join(data_file_location, state_gov_nm + 'embedded_legdoc.df')


# In[3]:


legcorpus = []
# mount dataset onto the mounted_path of a Linux-based compute
#mount_context = leg_text_ds.mount(local_ds_path)

#collect the legislative corpus
local_ds_path = tempfile.mkdtemp()

#mount_context.start()
#mount the azureml dataset
#if 1==1:
#with TemporaryDirectory() as local_ds_path:
with leg_text_ds.mount(local_ds_path):
    for f in listdir(local_ds_path):
        if state_gov_nm in f:
            _legcorpus = path.join(local_ds_path, f)
            with open(_legcorpus,'rb') as fl:
                legcorpus.extend(pickle.load(fl))    

#mount_context.end()
                
print(len(legcorpus))


# In[4]:


#legcorpus = [x[] if not isinstance(x[2], list) else x for x in legcorpus]
clean_legcorpus = []
for i, b in enumerate(legcorpus):    
    if not isinstance(b[2],list):
    #    print(i, type(b[2]))
        clean_legcorpus.append([b[0],b[1],[]])
    else:
        clean_legcorpus.append(b)


# In[5]:


texts = []
bill_id = []
doc_id = []
for b in clean_legcorpus:
    texts.append(b[2])
    bill_id.append(b[0])
    doc_id.append(b[1])


# In[6]:


# here we'll transform the legcorpus into a "tagged" document for use with doc2vec
# the tags will simply be the document ids.  Since we won't be using the predictor part of the operation, and only the resulting weights,
# we don't need to concern ourselves with labeling the documents
tagged_legdocs = []
for l in clean_legcorpus:
    #if i == 1:
        #print(td(l[2], [l[0]]))
#use doc ids
#    tagged_legdocs.append(td(l[2], [str(l[1])]))
#use bill_ids
    tagged_legdocs.append(td(l[2], [str(l[0])]))


# In[7]:


#loop through different vector lengths and deposit each into a separate file
for v in vector_size:
    embedder = d2v(tagged_legdocs, dm=1, alpha=.025,vector_size=v, min_alpha=.025, min_count=0, epochs=20, workers=16)
    embedder.train(tagged_legdocs, total_examples=embedder.corpus_count, epochs=embedder.epochs)
    print(len(embedder.docvecs))
    print(type(embedder.docvecs))
    # translate the embeddings and tags into a dataframe
    doc_embedding_list = []
    #for i in range(0,9):
    for i in range(len(embedder.docvecs)):
        #print(embedder.docvecs.index_to_doctag(i))
        doc_tag = embedder.docvecs.index_to_doctag(i)
        doc_vec = [doc_tag]
        doc_vec.extend(embedder.docvecs[doc_tag].tolist())
        #print(doc_vec)
        #doc_vec = doc_vec.tolist()

        doc_embedding_list.append(doc_vec)

    #DFlabels = ['doc_id']
    DFlabels = ['bill_id']
    
    for i in range(1, v + 1):
        DFlabels.append('dv' + str(i))

    print(DFlabels)

    doc_embed_DF = pd.DataFrame(doc_embedding_list, columns=DFlabels)
    
    _embeddings = path.join(data_file_location, state_gov_nm + str(v) + 'embedded_legdoc.df')
    
    #dump data out to a binary file
    with open(_embeddings,'wb') as f:
        pickle.dump(doc_embed_DF,f)
    
    #export the model
    _model = path.join(model_file_location, state_gov_nm + str(v) + '_embed.d2v')
    joblib.dump(embedder, _model)

