import pickle
from gensim.models import Doc2Vec as d2v
from gensim.models.doc2vec import TaggedDocument as td
import pandas as pd
from os import path
from os import listdir
import sys
from azureml.core import Dataset
from azureml.core import Workspace
import tempfile
import numpy as np
from sklearn.cluster import KMeans
from pprint import pprint
from time import time
import logging
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split
from tensorflow import feature_column
import tensorflow_hub as hub
from tensorflow.keras.callbacks import TensorBoard

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]

doc_vector_length = sys.argv[3]
doc_cluster_count = sys.argv[4]

# A utility method to create a tf.data dataset from a Pandas Dataframe
#labels are derived from the "passed" column
def df_to_dataset(dataframe, shuffle=True, batch_size=32):
  dataframe = dataframe.copy()
  labels = dataframe.pop('passed')
  ds = tf.data.Dataset.from_tensor_slices((dict(dataframe), labels))
  if shuffle:
    ds = ds.shuffle(buffer_size=len(dataframe))
  ds = ds.batch(batch_size)
  return ds

#this, VERY large script will be used in experiments to determine the best combination of features and
#parameters for the the Quigley Project. Sections of this will be turned into Python libraries to be called
#or as ADF pipelines to be executed in production.
#Individual elements can be tested within the notebooks and separate scripts.
#----------------------------------------------------------------------------------------------------------
#This section does the document embedding
#----------------------------------------------------------------------------------------------------------

#ws = Workspace.get(name="ml-quigley"
#                   , subscription_id='8d8bcbfe-86b4-42bb-a470-a8cf97c98d69'
#                   , resource_group='project-quigley')
ws = Workspace.from_config()

local_ds_path = tempfile.mkdtemp()

#define the azureml dataset
leg_text_ds = Dataset.get(ws,'leg_text_ds')

legcorpus = []

#mount the azureml dataset
#mount the dataset path and load the files
with leg_text_ds.mount(local_ds_path):
    for f in listdir(local_ds_path):
        if state_gov_nm in f:
            legcorpus = path.join(local_ds_path, f)
            with open(f,'rb') as fl:
                legcorpus.append(fl)

print(len(legcorpus))


clean_legcorpus = []
for i, b in enumerate(legcorpus):    
    if not isinstance(b[2],list):
        clean_legcorpus.append([b[0],b[1],[]])
    else:
        clean_legcorpus.append(b)

texts = []
bill_id = []
for b in clean_legcorpus:
    texts.append(b[2])
    bill_id.append(b[0])

# here we'll transform the legcorpus into a "tagged" document for use with doc2vec
# the tags will simply be the document ids.  Since we won't be using the predictor part of the operation, and only the resulting weights,
# we don't need to concern ourselves with labeling the documents
tagged_legdocs = []
for l in clean_legcorpus:
    tagged_legdocs.append(td(l[2], [str(l[0])]))

vector_size = doc_vector_length
embedder = d2v(tagged_legdocs, dm=1, alpha=.025,vector_size=vector_size, min_alpha=.025, min_count=0, epochs=20, workers=8)

embedder.train(tagged_legdocs, total_examples=embedder.corpus_count, epochs=embedder.epochs)

print(len(embedder.docvecs))
print(type(embedder.docvecs))

# translate the embeddings and tags into a dataframe
doc_embedding_list = []

for i in range(len(embedder.docvecs)):

    doc_tag = embedder.docvecs.index_to_doctag(i)
    doc_vec = [doc_tag]
    doc_vec.extend(embedder.docvecs[doc_tag].tolist())
    
    doc_embedding_list.append(doc_vec)

DFlabels = ['bill_id']

for i in range(1,vector_size + 1):
    DFlabels.append('dv' + str(i))

print(DFlabels)

docvecDF = pd.DataFrame(doc_embedding_list, columns=DFlabels)

#----------------------------------------------------------------------------------------------------------
#This section clusters the embedded documents
#----------------------------------------------------------------------------------------------------------

vectors = docvecDF.drop(columns=['bill_id'])

#create the model and feed in the document vectors
doc_clusters = KMeans(n_clusters = doc_cluster_count)
doc_labels = doc_clusters.fit_predict(vectors)

billCats = docvecDF.copy()
billCats['category'] = doc_labels

#----------------------------------------------------------------------------------------------------------
#This section accumulates the events
#----------------------------------------------------------------------------------------------------------

#local_ds_path = tempfile.mkdtemp()

#define the azureml dataset
leg_meta_ds = Dataset.get_by_name(ws,'leg_meta_ds')

#_embeddings = path.join(data_file_location, state_gov_nm + 'embedded_legdoc.df')
#_winlist = path.join(data_file_location, 'test.df')

#mount the dataset path and load the files
with leg_meta_ds.mount(local_ds_path):
    for f in listdir(local_ds_path):
        #if 1==1:
        #try:
        if state_gov_nm in f:
            _LegOverallData_CSV = path.join(local_ds_path, f)
            leg_data = leg_data.append(pd.read_csv(_LegOverallData_CSV))

        #except:
            #print("Error in file for:", f)
        #    continue
print(len(leg_data))

#create a cumulative event list for each time_t
#also creation of a column to determine when a pass or fail occurs, vs a regular move (can expand on this later on)
e_hist_list = []
prev_bill_id = 0
event_hist = ''
move_list = []
first = True
#iterate through the rows of the dataframe
for r in leg_data.iterrows():
    if r[1]['bill_id'] == prev_bill_id:
        event_hist = event_hist + str(r[1]['event']) + '->'
        e_hist_list.append(event_hist)
        if 'enacted' in event_hist:
            move_list.append('Pass')
        else:
            move_list.append('Move')
    else:
        event_hist = str(r[1]['event']) + '->'
        e_hist_list.append(event_hist)
        if first:
            first = False
        elif move_list[-1] != 'Pass':
            move_list[-1] = 'Fail'
        
        move_list.append('Move')
        
    prev_bill_id = r[1]['bill_id']

#add the new lists as columns in the dataframe
leg_data['cmltv_event'] = e_hist_list
leg_data['move'] = move_list

#leg_to_export = leg_data[['bill_id','time_t','cmltv_event','move']].copy()

#----------------------------------------------------------------------------------------------------------
#This section creates the datasets and feature layer
#----------------------------------------------------------------------------------------------------------

#leg_data_raw = pd.DataFrame()
LegSponsorDF = pd.DataFrame()
#legcorpus = []
years = []
vectors = []
chambers = []
##win_state = []
#_legtext = path.join(data_file_location,state_gov_nm + 'embedded_legdoc.df')
#_bill_clusters = path.join(data_file_location,state_gov_nm + 'bill_clusters.df')
#_sponsors = path.join(data_file_location, state_gov_nm + 'Sponsors.csv') 
#_cmltv_event_df = path.join(data_file_location,state_gov_nm + 'cmltv_events.df')
#_LegPeopleData_CSV = path.join(data_file_location, state_gov_nm + year_to_process + 'LegPeopleData.csv')
##_SessionBodyVector = path.join(data_file_location, state_gov_nm + year_to_process + 'SessionBodyVector.int')
#_SessionBodyVector = path.join(data_file_location, state_gov_nm + year_to_process + 'SessionBodyVector.tuple')
#_predictions = path.join(data_file_location,state_gov_nm + year_to_process + 'Predictions.csv')

#for i in range(2009, int(year_to_process)+1):
    try:       
        
        if 'Sponsors' in f:

            LegSponsorDF = LegSponsorDF.append(pd.read_csv(_LegPeopleData_CSV))
        
        vec_temp = 0
        _SessionBodyVector = path.join(data_file_location, state_gov_nm + str(i) + 'SessionBodyVector.tuple')
        #_SessionBodyVector = path.join(data_file_location, state_gov_nm + str(i) + 'SessionBodyVector.int')
        with open(_SessionBodyVector,'rb') as f:
            years.append(i)
            years.append(i)
            vec_temp = pickle.load(f)
            print(vec_temp)
            chambers.append('H')
            chambers.append('S')
            vectors.append(vec_temp[0])
            vectors.append(vec_temp[1])
        
    except:
        print("Error in file for:",i)
        continue

with open(_legtext,'rb') as f:
    legtextembed = pickle.load(f)

with open(_cmltv_event_df,'rb') as f:
    cmltv_event = pickle.load(f)

with open(_bill_clusters,'rb') as f:
    billcat = pickle.load(f)
    
#sponsor_df = pd.read_csv(_sponsors)
#sponsor_df.set_index('bill_id', in_place = True)

leg_data = leg_data_raw

#define the sponsors as categorical variables and create dummy columns

LegSponsorDF['sponsors'] = pd.Categorical(LegSponsorDF['sponsors'],categories=LegSponsorDF['sponsors'].unique())


LegSponsorDF = pd.get_dummies(LegSponsorDF, columns=['sponsors'])
LegSponsorDF = LegSponsorDF.groupby(['bill_id']).sum()

#create the session vector dictionary
SessionBodyVectors = {'year' : years, 'chamber' : chambers, 'partisan_vector' : vectors}

SessionBodyMakeup = pd.DataFrame(SessionBodyVectors)
print(SessionBodyMakeup.head)


print(SessionBodyVectors)
print(SessionBodyMakeup.head)

##########################################################################################
#Clean up dataframes
#legtextembed = legtextembed.drop_duplicates(subset=['bill_id'])
#legtextembed = legtextembed.set_index('bill_id')
billcat['bill_id'] = billcat['bill_id'].astype('int64')
#leg_data = leg_data.drop_duplicates(subset=['bill_id']) #should probably be bill_id
#leg_data = leg_data.set_index('bill_id')
leg_data = leg_data.drop(columns=['event', 'Unnamed: 0', 'primary_id','title','committee_introduced'])


leg_data['chamber'] = leg_data['chamber'].fillna('None')
leg_data['primary_name'] = leg_data['primary_name'].fillna('None')
leg_data['primary_party'] = leg_data['primary_party'].fillna('N')

#adjust the number of sponsors, based on the max value found in the field (for future iterations, just divide by the number in that particular chamber)
max_sponsors = leg_data['number_sponsors'].max()
leg_data['num_sponsors_adj'] = (leg_data['number_sponsors']*1.00)/max_sponsors

#filtering out all types of legislation except bills (no resolutions, constitutional ammendments, etc.)
leg_data = leg_data[leg_data['bill_type']=='B']

print(len(leg_data), len(legtextembed))

#leg_data = leg_data.join(legtextembed)
print(len(leg_data[leg_data['year']==int(year_to_process)]))
leg_data = pd.merge(leg_data, billcat, how='inner', on=['bill_id'])
print(len(leg_data[leg_data['year']==int(year_to_process)]))
leg_data = pd.merge(leg_data, cmltv_event, how='inner', on=['bill_id','time_t'])
print(len(leg_data[leg_data['year']==int(year_to_process)]))
leg_data = pd.merge(leg_data, LegSponsorDF, how='inner', on=['bill_id'])
print(len(leg_data[leg_data['year']==int(year_to_process)]))
leg_data = pd.merge(leg_data, SessionBodyMakeup, how='inner', on=['year','chamber'])
print(len(leg_data[leg_data['year']==int(year_to_process)]))
leg_data = leg_data.drop(columns=['Unnamed: 0'])

print(leg_data.head())

print(len(leg_data[leg_data['year']==int(year_to_process)]))

train_set = leg_data[leg_data['year']<int(year_to_process)]
test_set = leg_data[leg_data['year']==int(year_to_process)]
#prediction_set = leg_data[leg_data['year']==int(year_to_process)]

test = test_set

#create a balanced train/test split

data_pass = leg_data[leg_data['passed']==1]
data_fail = leg_data[leg_data['passed']==0]

if len(data_pass) > len(data_fail):
    data_pass  = data_pass.iloc[:len(data_fail)]
else:
    data_fail = data_fail.iloc[:len(data_pass)]

print(len(data_pass))
print(len(data_fail))

#combine the balanced sets and shuiffle
balanced_train = pd.concat([data_pass, data_fail])
balanced_train = balanced_train.sample(frac=1)
balanced_train = balanced_train.sample(frac=1)

#pull out a validation set
train, val = train_test_split(balanced_train, test_size=.25)

print(len(train), 'train examples')
print(len(val), 'validation examples')
print(len(test), 'test examples')

print(len(train_set))

#--------------------------------------------------------------------------------------------------
#remove all but the latest entries for the test data set
#this will grab the highest time_t for a given bill_id and then apply the index of that to the original data frame
#This will take our test data and only look at the latest status of it to determine pass or failure
#only do this for the prediction set!!!!! not the testing set as those ran the full course.  For that we need a random sampling as a test.

#idx = test.groupby(['bill_id'])['time_t'].transform(max) == test['time_t']
#test = test[idx]
#print(len(test))

#for testing purposes, we need to  reorder the rows, drop duplicates based on the bill_id.
#the sample method returns a random sampling of the rows, based on the "frac" parameter.  1 will return all rows.
#--------------------------------------------------------------------------------------------------
test = test.sample(frac=1)
test = test.sample(frac=1)
print(test.head())
test = test.drop_duplicates(subset='bill_id')
#--------------------------------------------------------------------------------------------------

print(len(test))

feature_columns = []

numericfeaturelist = [
                        'sponsor_vec', #change to -1 to 1
                        'partisan_vector'
                       # 'num_sponsors_adj'
                      #, 'intro_to_end_of_session' -- in CA, this causes weird results
                      #, 'last_event_to_end_of_session'
                      ]

for dv in range(1, doc_vector_length + 1):
    numericfeaturelist.append('dv' + str(dv))

sponsors_cols = [col for col in leg_data.columns if 'sponsors_' in col]
#print(sponsors_cols)
numericfeaturelist.extend(sponsors_cols)

#print(numericfeaturelist)

#numeric cols
for header in numericfeaturelist:
    feature_columns.append(feature_column.numeric_column(header))

# bucketized cols
#age_buckets = feature_column.bucketized_column(age, boundaries=[18, 25, 30, 35, 40, 45, 50, 55, 60, 65])
#feature_columns.append(age_buckets)

# indicator cols
primary_party = feature_column.categorical_column_with_vocabulary_list('primary_party', leg_data['primary_party'].unique())
primary_party_onehot = feature_column.indicator_column(primary_party)
feature_columns.append(primary_party_onehot)

time_t = feature_column.categorical_column_with_vocabulary_list('time_t', leg_data['time_t'].unique())
time_t_onehot = feature_column.indicator_column(time_t)
feature_columns.append(time_t_onehot)

primary_sponsor = feature_column.categorical_column_with_vocabulary_list('primary_name', leg_data['primary_name'].unique())
primary_sponsor_onehot = feature_column.indicator_column(primary_sponsor)
feature_columns.append(primary_sponsor_onehot)

bill_category = feature_column.categorical_column_with_vocabulary_list('category', leg_data['category'].unique())
bill_category_onehot = feature_column.indicator_column(bill_category)
feature_columns.append(bill_category_onehot)

# embedding cols
event_list = feature_column.categorical_column_with_vocabulary_list('cmltv_event', leg_data['cmltv_event'].unique())
event_list_onehot = feature_column.indicator_column(event_list)
event_list_embed = feature_column.embedding_column(event_list, dimension=30)

#feature_columns.append(event_list_embed)
feature_columns.append(event_list_onehot)
#primary_embedding = feature_column.embedding_column(primary_sponsor, dimension=8)

feature_layer = tf.keras.layers.DenseFeatures(feature_columns)

batch_size = 1024
train_ds = df_to_dataset(train, shuffle = True, batch_size=batch_size)
val_ds = df_to_dataset(val, shuffle=True, batch_size=batch_size)
test_ds = df_to_dataset(test, shuffle=False, batch_size=batch_size)

#----------------------------------------------------------------------------------------------------------
#This section trains and scores the model
#----------------------------------------------------------------------------------------------------------

#define the model
model = tf.keras.Sequential([
  feature_layer,
  layers.Dense(1000, activation='relu'),
  layers.Dropout(.5),
  layers.Dense(250, activation='relu'),
  layers.Dropout(.25),
  layers.Dense(1000, activation='relu'),
  layers.Dropout(.5),
  layers.Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam',
              loss=tf.keras.losses.BinaryCrossentropy(from_logits=True),
              metrics=['accuracy'
                       , tf.keras.metrics.Precision()
                       , tf.keras.metrics.Recall()
                      ])

#train the model
model.fit(train_ds,
          validation_data=val_ds,
          epochs=25
         )

#grab the accuracy metrics from the test dataset
loss, accuracy, precision, recall = model.evaluate(test_ds)
print("Accuracy:", accuracy, "Precision:", precision, "Recall:",recall)