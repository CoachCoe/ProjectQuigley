import pickle
import argparse
import pandas as pd
from os import path
from os import listdir
from azureml.core import Dataset, Workspace, Datastore
#from azureml.data import FileDataset
import tempfile
import numpy as np
from pprint import pprint
import tensorflow as tf
from tensorflow import keras, feature_column
from tensorflow.keras import layers
from azureml.core import Run
from azureml.core.authentication import ServicePrincipalAuthentication

#python file local to the src directory
from pg_oc_data_prep import doc_embeddings, cluster_documents, accumulate_events, df_to_dataset, train_test_split_by_year, create_feature_layer

run = Run.get_context()

if __name__ == "__main__":
    #parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--state_gov_nm', type=str, help='State to train')
    parser.add_argument('--year_to_process', type=int, default=2020, help='Year to train up to (this year not included)')
    parser.add_argument('--doc_vector_length', type=int, default=128, help='Length of the leg text doc vector')
    parser.add_argument('--doc_cluster_count', type=int, default=50, help='Number of categories to create for leg text')
    parser.add_argument('--curr_year', type=bool, default=1, help='Are you running for the current year?')
    args = parser.parse_args()

    #assign the arguments to variables
    state_gov_nm = args.state_gov_nm
    year_to_process = args.year_to_process
    curr_year = args.curr_year
    vector_size = args.doc_vector_length
    number_of_clusters = args.doc_cluster_count

    #Define the workspace and experiment to use
    #ws = Workspace.from_config(path='.azureml/')
    sp = ServicePrincipalAuthentication(tenant_id="26abc6ef-f140-44d3-87ec-94ac09fd36d2", # tenantID
                                        service_principal_id="b7431496-79ec-4906-915d-de3ca0970716", # clientId
                                        service_principal_password=) # clientSecret

    #ws = Workspace.from_config(path='.azureml/')
    ws = Workspace.get(name="ml-quigley"
                    , subscription_id='8d8bcbfe-86b4-42bb-a470-a8cf97c98d69'
                    , resource_group='project-quigley'
                    ,auth=sp
                        )

    #define the datastore to upload the final CSVs to
    datastore = Datastore.get(ws, 'quigleydl')

    #collect the legislative corpus
    local_ds_path = tempfile.mkdtemp()

    #define the azureml dataset
    leg_text_ds = Dataset.get_by_name(ws,'leg_text_ds')
    LegSponsorDF = pd.DataFrame()
    leg_data = pd.DataFrame()
    legcorpus = []

    #get the corpus
    #mount the datastore and create the combined corpus object
    with leg_text_ds.mount(local_ds_path):
        for f in listdir(local_ds_path):
            if state_gov_nm in f:
                _legcorpus = path.join(local_ds_path, f)
                with open(_legcorpus,'rb') as fl:
                    legcorpus.extend(pickle.load(fl))

    print(len(legcorpus))
    


    #get the metadata
    leg_meta_ds = Dataset.get_by_name(ws,'leg_meta_ds')

    with leg_meta_ds.mount(local_ds_path):
        for f in listdir(local_ds_path):

            if state_gov_nm in f:
                _LegOverallData_CSV = path.join(local_ds_path, f)
                leg_data = leg_data.append(pd.read_csv(_LegOverallData_CSV))

    print(len(leg_data))

    #get the sponsor and people data----------------------------------------------------

    years = [2010,2010,2012,2012,2014,2014,2016,2016,2018,2018,2020,2020]
    chambers = []
    vectors = []

    leg_people_ds = Dataset.get_by_name(ws,'leg_people_ds')
    
    with leg_people_ds.mount(local_ds_path):
        for f in listdir(local_ds_path):
            if 'People' in f and state_gov_nm in f:
                
                _LegPeopleData_CSV = path.join(local_ds_path,f)
                LegSponsorDF = LegSponsorDF.append(pd.read_csv(_LegPeopleData_CSV))
            
            vec_temp = 0
            if 'SessionBodyVector' in f and state_gov_nm in f:
                _SessionBodyVector = path.join(local_ds_path, f)
                with open(_SessionBodyVector,'rb') as fl:
                    #years.append(i)
                    #years.append(i)
                    vec_temp = pickle.load(fl)
                    print(vec_temp)
                    chambers.append('H')
                    chambers.append('S')
                    vectors.append(vec_temp[0])
                    vectors.append(vec_temp[1])

    #alter the dataframes as necessary for merging into the leg_data dataframe
    LegSponsorDF['sponsors'] = pd.Categorical(LegSponsorDF['sponsors'],categories=LegSponsorDF['sponsors'].unique())

    LegSponsorDF = pd.get_dummies(LegSponsorDF, columns=['sponsors'])
    LegSponsorDF = LegSponsorDF.groupby(['bill_id']).sum()

    #create the session vector dictionary
    SessionBodyVectors = {'year' : years, 'chamber' : chambers, 'partisan_vector' : vectors}

    SessionBodyMakeup = pd.DataFrame(SessionBodyVectors)
    print(SessionBodyMakeup.head)
    print(SessionBodyVectors)
    print(SessionBodyMakeup.head)
    #------------------------------------------------------------------------------------

    #run the necessary data prep functions
    leg_doc_embeddings = doc_embeddings(legtext_corpus = legcorpus, vector_size = vector_size)
    leg_doc_clusters = cluster_documents(legtext_embeddings = leg_doc_embeddings, number_of_clusters = number_of_clusters)
    leg_event_accumulated = accumulate_events(leg_meta_data = leg_data)

    ##########################################################################################
    #Clean up and combine the dataframes
    leg_doc_clusters['bill_id'] = leg_doc_clusters['bill_id'].astype('int64')
    leg_data = leg_data.drop(columns=['event', 'Unnamed: 0', 'primary_id','title','committee_introduced'])

    leg_data['chamber'] = leg_data['chamber'].fillna('None')
    leg_data['primary_name'] = leg_data['primary_name'].fillna('None')
    leg_data['primary_party'] = leg_data['primary_party'].fillna('N')

    #adjust the number of sponsors, based on the max value found in the field (for future iterations, just divide by the number in that particular chamber)
    max_sponsors = leg_data['number_sponsors'].max()
    leg_data['num_sponsors_adj'] = (leg_data['number_sponsors']*1.00)/max_sponsors

    #filtering out all types of legislation except bills (no resolutions, constitutional ammendments, etc.)
    leg_data = leg_data[leg_data['bill_type']=='B']

    #print(len(leg_data), len(legtextembed))

    #leg_data = leg_data.join(legtextembed)
    print(len(leg_data[leg_data['year']==int(year_to_process)]))
    leg_data = pd.merge(leg_data, leg_doc_clusters, how='inner', on=['bill_id'])
    print(len(leg_data[leg_data['year']==int(year_to_process)]))
    leg_data = pd.merge(leg_data, leg_event_accumulated, how='inner', on=['bill_id','time_t'])
    print(len(leg_data[leg_data['year']==int(year_to_process)]))
    print(leg_data['cmltv_event'].head)
    leg_data = pd.merge(leg_data, LegSponsorDF, how='inner', on=['bill_id'])
    print(len(leg_data[leg_data['year']==int(year_to_process)]))
    leg_data = pd.merge(leg_data, SessionBodyMakeup, how='inner', on=['year','chamber'])
    print(len(leg_data[leg_data['year']==int(year_to_process)]))
    leg_data = leg_data.drop(columns=['Unnamed: 0'])

    print(leg_data.head())
    print(len(leg_data[leg_data['year']==int(year_to_process)]))

    #should probably output an artifact at this point, since the dataset would be ready for running
    train, val, test = train_test_split_by_year(full_data = leg_data, year_to_process = year_to_process, curr_year = curr_year)

    feature_layer = create_feature_layer(full_data = leg_data, doc_vector_length = vector_size)

    #create batch datasets
    batch_size = 1024
    train_ds = df_to_dataset(train, shuffle = True, batch_size=batch_size)
    val_ds = df_to_dataset(val, shuffle=True, batch_size=batch_size)
    test_ds = df_to_dataset(test, shuffle=False, batch_size=batch_size)

    #define the model
    model = tf.keras.Sequential([
    feature_layer,
    layers.Dense(1000, activation='relu'),
    layers.Dropout(.5),
    layers.Dense(250, activation='relu'),
    layers.Dropout(.25),
    layers.Dense(1000, activation='relu'),
    layers.Dropout(.5),
    layers.Dense(1, activation='sigmoid')
    ])

    model.compile(optimizer='adam',
                loss=tf.keras.losses.BinaryCrossentropy(from_logits=True),
                metrics=['accuracy'
                        , tf.keras.metrics.Precision()
                        , tf.keras.metrics.Recall()
                        ])

    #train the model
    model.fit(train_ds,
            validation_data=val_ds,
            epochs=25
            )

    #grab the accuracy metrics from the test dataset
    loss, accuracy, precision, recall = model.evaluate(test_ds)
    #run.log( "State: " + state_gov_nm + " Year: " + str(year_to_process)
    #        + " Vector Size: " + str(vector_size) + " Categories: " + str(number_of_clusters)
    #        + " Accuracy: " + str(accuracy) + " Precision: " + str(precision) + " Recall: " + str(recall))
    
    predictions = model.predict(test_ds)
    test['pred'] = predictions
    test.to_csv('./' + state_gov_nm + str(year_to_process) + '.csv')
    datastore = ws.get_default_datastore()
    datastore.upload(src_dir='./' + state_gov_nm + str(year_to_process) + '.csv', target_path='output/predictions', overwrite=True)
