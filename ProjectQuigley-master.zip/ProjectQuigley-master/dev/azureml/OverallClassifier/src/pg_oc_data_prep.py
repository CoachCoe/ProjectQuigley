import pickle
from gensim.models import Doc2Vec as d2v
from gensim.models.doc2vec import TaggedDocument as td
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
import logging
import tensorflow as tf
from tensorflow import feature_column

def doc_embeddings(legtext_corpus, vector_size):
    
    legcorpus = legtext_corpus
    clean_legcorpus = []
    for i, b in enumerate(legcorpus):    
        if not isinstance(b[2],list):
        #    print(i, type(b[2]))
            clean_legcorpus.append([b[0],b[1],[]])
        else:
            clean_legcorpus.append(b)

    texts = []
    bill_id = []
    for b in clean_legcorpus:
        texts.append(b[2])
        bill_id.append(b[0])

    # here we'll transform the legcorpus into a "tagged" document for use with doc2vec
    # the tags will simply be the document ids.  Since we won't be using the predictor part of the operation, and only the resulting weights,
    # we don't need to concern ourselves with labeling the documents
    tagged_legdocs = []
    for l in clean_legcorpus:
        #if i == 1:
            #print(td(l[2], [l[0]]))
        tagged_legdocs.append(td(l[2], [str(l[0])]))

    #vector_size = 128
    embedder = d2v(tagged_legdocs, dm=1, alpha=.025,vector_size=vector_size, min_alpha=.025, min_count=0, epochs=20, workers=8)

    embedder.train(tagged_legdocs, total_examples=embedder.corpus_count, epochs=embedder.epochs)

    print(len(embedder.docvecs))
    print(type(embedder.docvecs))

    # translate the embeddings and tags into a dataframe
    doc_embedding_list = []
    
    for i in range(len(embedder.docvecs)):
        doc_tag = embedder.docvecs.index_to_doctag(i)
        doc_vec = [doc_tag]
        doc_vec.extend(embedder.docvecs[doc_tag].tolist())
        
        doc_embedding_list.append(doc_vec)

    DFlabels = ['bill_id']

    for i in range(1,vector_size + 1):
        DFlabels.append('dv' + str(i))

    print(DFlabels)

    doc_embed_DF = pd.DataFrame(doc_embedding_list, columns=DFlabels)

    return doc_embed_DF

def cluster_documents(legtext_embeddings, number_of_clusters):
    
    docvecDF = legtext_embeddings.copy()
    vectors = docvecDF.drop(columns=['bill_id'])
    
    #create the model and feed in the document vectors
    doc_clusters = KMeans(n_clusters = number_of_clusters)
    doc_labels = doc_clusters.fit_predict(vectors)

    billCats = docvecDF.copy()
    
    billCats['category'] = doc_labels

    print(billCats['category'].unique())

    return billCats

def accumulate_events(leg_meta_data):
    #create a cumulative event list for each time_t
    #also creation of a column to determine when a pass or fail occurs, vs a regular move (can expand on this later on)
    e_hist_list = []
    prev_bill_id = 0
    event_hist = ''
    move_list = []
    first = True
    leg_data = leg_meta_data.copy()
    #iterate through the rows of the dataframe
    for r in leg_data.iterrows():
        if r[1]['bill_id'] == prev_bill_id:
            event_hist = event_hist + str(r[1]['event']) + '->'
            e_hist_list.append(event_hist)
            if 'enacted' in event_hist:
                move_list.append('Pass')
            else:
                move_list.append('Move')
        else:
            event_hist = str(r[1]['event']) + '->'
            e_hist_list.append(event_hist)
            if first:
                first = False
            elif move_list[-1] != 'Pass':
                move_list[-1] = 'Fail'
            
            move_list.append('Move')
            
        prev_bill_id = r[1]['bill_id']

    #add the new lists as columns in the dataframe
    leg_data['cmltv_event'] = e_hist_list
    leg_data['move'] = move_list

    leg_to_export = leg_data[['bill_id','time_t','cmltv_event','move']].copy()

    return leg_to_export

#create batch datasets for Tensorflow
def df_to_dataset(dataframe, shuffle=True, batch_size=32):
  dataframe = dataframe.copy()
  labels = dataframe.pop('passed')
  ds = tf.data.Dataset.from_tensor_slices((dict(dataframe), labels))
  if shuffle:
    ds = ds.shuffle(buffer_size=len(dataframe))
  ds = ds.batch(batch_size)
  return ds


def train_test_split_by_year(full_data, year_to_process, curr_year):
    leg_data = full_data.copy()
    train_set = leg_data[leg_data['year']<int(year_to_process)]
    test_set = leg_data[leg_data['year']==int(year_to_process)]
    #prediction_set = leg_data[leg_data['year']==int(year_to_process)]
    test = test_set
    #create a balanced train/test split

    data_pass = leg_data[leg_data['passed']==1]
    data_fail = leg_data[leg_data['passed']==0]

    if len(data_pass) > len(data_fail):
        data_pass  = data_pass.iloc[:len(data_fail)]
    else:
        data_fail = data_fail.iloc[:len(data_pass)]

    print(len(data_pass))
    print(len(data_fail))

    #combine the balanced sets and shuiffle
    balanced_train = pd.concat([data_pass, data_fail])
    balanced_train = balanced_train.sample(frac=1)
    balanced_train = balanced_train.sample(frac=1)

    #pull out a validation set
    train, val = train_test_split(balanced_train, test_size=.25)

    print(len(train), 'train examples')
    print(len(val), 'validation examples')
    print(len(test), 'test examples')

    print(len(train_set))

    if curr_year:
        idx = test.groupby(['bill_id'])['time_t'].transform(max) == test['time_t']
        test = test[idx]
        print(len(test))
    
    else:
        test = test.sample(frac=1)
        test = test.sample(frac=1)
        print(test.head())
        test = test.drop_duplicates(subset='bill_id')

    return train, val, test


def create_feature_layer(full_data, doc_vector_length):
    feature_columns = []
    leg_data = full_data
    numericfeaturelist = [
                            'sponsor_vec' #change to -1 to 1
                         ,   'partisan_vector'
                        #, 'num_sponsors_adj'
                        #, 'intro_to_end_of_session' -- in CA, this causes weird results
                        #, 'last_event_to_end_of_session'
                        ]

    for dv in range(1, doc_vector_length + 1):
        numericfeaturelist.append('dv' + str(dv))

    sponsors_cols = [col for col in leg_data.columns if 'sponsors_' in col]

    numericfeaturelist.extend(sponsors_cols)

    #numeric cols
    for header in numericfeaturelist:
        feature_columns.append(feature_column.numeric_column(header))

    # indicator cols
    primary_party = feature_column.categorical_column_with_vocabulary_list('primary_party', leg_data['primary_party'].unique())
    primary_party_onehot = feature_column.indicator_column(primary_party)
    feature_columns.append(primary_party_onehot)

    time_t = feature_column.categorical_column_with_vocabulary_list('time_t', leg_data['time_t'].unique())
    time_t_onehot = feature_column.indicator_column(time_t)
    feature_columns.append(time_t_onehot)

    primary_sponsor = feature_column.categorical_column_with_vocabulary_list('primary_name', leg_data['primary_name'].unique())
    primary_sponsor_onehot = feature_column.indicator_column(primary_sponsor)
    feature_columns.append(primary_sponsor_onehot)

    bill_category = feature_column.categorical_column_with_vocabulary_list('category', leg_data['category'].unique())
    bill_category_onehot = feature_column.indicator_column(bill_category)
    feature_columns.append(bill_category_onehot)

    # embedding cols
    event_list = feature_column.categorical_column_with_vocabulary_list('cmltv_event', leg_data['cmltv_event'].unique())
    event_list_onehot = feature_column.indicator_column(event_list)
    #event_list_embed = feature_column.embedding_column(event_list, dimension=30)

    #feature_columns.append(event_list_embed)
    feature_columns.append(event_list_onehot)
    #primary_embedding = feature_column.embedding_column(primary_sponsor, dimension=8)

    feature_layer = tf.keras.layers.DenseFeatures(feature_columns)

    return feature_layer