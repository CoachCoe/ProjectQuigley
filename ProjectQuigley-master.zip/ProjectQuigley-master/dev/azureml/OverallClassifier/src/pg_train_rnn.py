import pickle
import argparse
import pandas as pd
from os import path
from os import listdir
from azureml.core import Dataset, Workspace
#from azureml.data import FileDataset
import tempfile
import numpy as np
from pprint import pprint
import tensorflow as tf
from tensorflow import keras, feature_column
from tensorflow.keras import layers

#python file local to the src directory
from pg_oc_data_prep import doc_embeddings, cluster_documents, accumulate_events, df_to_dataset, train_test_split_by_year, create_feature_layer

