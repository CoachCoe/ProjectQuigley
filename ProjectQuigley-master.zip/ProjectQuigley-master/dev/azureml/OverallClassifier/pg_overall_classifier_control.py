# tutorial/03-run-hello.py
from azureml.core import Workspace, Experiment, Environment, ScriptRunConfig
from azureml.core.authentication import ServicePrincipalAuthentication
from os import environ

sp = ServicePrincipalAuthentication(tenant_id="26abc6ef-f140-44d3-87ec-94ac09fd36d2", # tenantID
                                    service_principal_id="b7431496-79ec-4906-915d-de3ca0970716", # clientId
                                    service_principal_password=environ.get('MLQuigleySecret')) # clientSecret

#ws = Workspace.from_config(path='.azureml/')
ws = Workspace.get(name="ml-quigley"
                   , subscription_id='8d8bcbfe-86b4-42bb-a470-a8cf97c98d69'
                   , resource_group='project-quigley'
                   ,auth=sp
                    )

experiment = Experiment(workspace=ws, name='quigley-overall-classifier')

config = ScriptRunConfig(source_directory='./src'
                        , script='pg_train_overall_classifier.py'
                        , compute_target='quigley-gpu'
                        #, compute_target='Beefy'
                        ,arguments = ['--state_gov_nm','PA','--year_to_process',2020,'--doc_vector_length',32,'--doc_cluster_count',50, '--curr_year', True])

#setup the tensorflow environment
env = Environment.from_conda_specification(name='overall-classifier-env',file_path='.azureml/overall-classifier-env.yml')
config.run_config.environment = env

#register the environment
#env.register(ws)

run = experiment.submit(config)
aml_url = run.get_portal_url()
print(aml_url)