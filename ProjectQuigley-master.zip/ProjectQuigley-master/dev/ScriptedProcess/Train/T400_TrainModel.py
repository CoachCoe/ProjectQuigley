import pickle
import numpy as np
import pandas as pd
from pprint import pprint
from time import time
import logging
import sys
import tensorflow as tf
from os import path
from os import listdir
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split
from tensorflow import feature_column
from tensorflow.keras.callbacks import TensorBoard
from azureml.core import Dataset, Workspace
import joblib

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]
model_file_location = sys.argv[4]
vector_size = sys.argv[5]
cluster_size = sys.argv[6]

# A utility method to create a tf.data dataset from a Pandas Dataframe
#labels are derived from the "passed" column
def df_to_dataset(dataframe, shuffle=True, batch_size=32):
  dataframe = dataframe.copy()
  labels = dataframe.pop('passed')
  ds = tf.data.Dataset.from_tensor_slices((dict(dataframe), labels))
  if shuffle:
    ds = ds.shuffle(buffer_size=len(dataframe))
  ds = ds.batch(batch_size)
  return ds

def train_model(state_gov_nm, year_to_process, data_file_location, model_file_location, vector_size, cluster_size):

    _dataset = path.join(data_file_location, state_gov_nm + str(vector_size) + str(cluster_size) + '_dataset.df')

    with open(_dataset, 'rb') as f:
        leg_data = pickle.load(f)

    train_set = leg_data[leg_data['year']<int(year_to_process)]

    #create a balanced train/test split

    data_pass = leg_data[leg_data['passed']==1]
    data_fail = leg_data[leg_data['passed']==0]

    if len(data_pass) > len(data_fail):
        data_pass  = data_pass.iloc[:len(data_fail)]
    else:
        data_fail = data_fail.iloc[:len(data_pass)]

    print(len(data_pass))
    print(len(data_fail))

    #combine the balanced sets and shuiffle
    balanced_train = pd.concat([data_pass, data_fail])
    balanced_train = balanced_train.sample(frac=1)
    balanced_train = balanced_train.sample(frac=1)

    #pull out a validation set
    train, val = train_test_split(balanced_train, test_size=.25)

    print(len(train), 'train examples')
    print(len(val), 'validation examples')

    len(train['time_t'].unique())


    #this section creates the feature layer that serves as the input for the NN
    feature_columns = []

    numericfeaturelist = [
                            'sponsor_vec', #change to -1 to 1
                            'partisan_vector'
                        ]

    for dv in range(1, vector_size+1):
        numericfeaturelist.append('dv' + str(dv))

    sponsors_cols = [col for col in leg_data.columns if 'sponsors_' in col]

    numericfeaturelist.extend(sponsors_cols)

    #numeric cols
    for header in numericfeaturelist:
        feature_columns.append(feature_column.numeric_column(header))

    # indicator cols
    primary_party = feature_column.categorical_column_with_vocabulary_list('primary_party', leg_data['primary_party'].unique())
    primary_party_onehot = feature_column.indicator_column(primary_party)
    feature_columns.append(primary_party_onehot)

    time_t = feature_column.categorical_column_with_vocabulary_list('time_t', leg_data['time_t'].unique())
    time_t_onehot = feature_column.indicator_column(time_t)
    feature_columns.append(time_t_onehot)

    primary_sponsor = feature_column.categorical_column_with_vocabulary_list('primary_name', leg_data['primary_name'].unique())
    primary_sponsor_onehot = feature_column.indicator_column(primary_sponsor)
    feature_columns.append(primary_sponsor_onehot)

    bill_category = feature_column.categorical_column_with_vocabulary_list('category', leg_data['category'].unique())
    bill_category_onehot = feature_column.indicator_column(bill_category)
    feature_columns.append(bill_category_onehot)

    event_list = feature_column.categorical_column_with_vocabulary_list('cmltv_event', leg_data['cmltv_event'].unique())
    event_list_onehot = feature_column.indicator_column(event_list)

    feature_columns.append(event_list_onehot)

    print(len(feature_columns))

    feature_layer = tf.keras.layers.DenseFeatures(feature_columns)

    batch_size = 512
    train_ds = df_to_dataset(train, shuffle = True, batch_size=batch_size)
    val_ds = df_to_dataset(val, shuffle=True, batch_size=batch_size)

    model = tf.keras.Sequential([
        feature_layer,
        layers.Dense(1000, activation='relu'),
        layers.Dropout(.5),
        layers.Dense(250, activation='relu'),
        layers.Dropout(.25),
        layers.Dense(1000, activation='relu'),
        layers.Dropout(.5),
        layers.Dense(1, activation='sigmoid')
        ])

    model.compile(optimizer='adam',
                loss=tf.keras.losses.BinaryCrossentropy(from_logits=True),
                metrics=['accuracy'
                        , tf.keras.metrics.Precision()
                        , tf.keras.metrics.Recall()
                        ])

    model.fit(train_ds,
            validation_data=val_ds,
            epochs=15
            )

    #export the model
    try:
        _model = path.join(model_file_location, 'model/' + state_gov_nm + '/'+ state_gov_nm + 'overall.tf')
        model.save(_model
                    ,overwrite=True
                    ,include_optimizer=True
                    ,save_format=None
                    ,signatures=None
                    ,options=None)
    except:
        print("Could not save model.")
