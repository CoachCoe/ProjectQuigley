import pickle
import numpy as np
import pandas as pd
from pprint import pprint
from time import time
import logging
import sys
import tensorflow as tf
from os import path
from os import listdir
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split
from tensorflow import feature_column
from tensorflow.keras.callbacks import TensorBoard
from azureml.core import Dataset, Workspace
from tempfile import TemporaryDirectory
import tempfile
import sys

def create_training_dataset(state_gov_nm, year_to_process, data_file_location, vector_size, cluster_size, ws):

    local_ds_path = tempfile.mkdtemp()

    #define the azureml dataset
    leg_meta_ds = Dataset.get_by_name(ws,'leg_meta_ds')

    _cmltv_event_df = path.join(data_file_location, state_gov_nm + 'cmltv_events.df')

    v = vector_size
    c = cluster_size

    years = []
    chambers = []
    vectors = []
    leg_data_raw = pd.DataFrame()
    LegSponsorDF = pd.DataFrame()

    with leg_meta_ds.mount(local_ds_path):
        for f in listdir(local_ds_path):
            if state_gov_nm in f:
                _LegOverallData_CSV = path.join(local_ds_path, f)
                leg_data_raw = leg_data_raw.append(pd.read_csv(_LegOverallData_CSV))

    leg_people_ds = Dataset.get_by_name(ws,'leg_people_ds')

    with leg_people_ds.mount(local_ds_path):
        for f in listdir(local_ds_path):
            if 'LegPeopleData.csv' in f and state_gov_nm in f:
                
                _LegPeopleData_CSV = path.join(local_ds_path,f)
                LegSponsorDF = LegSponsorDF.append(pd.read_csv(_LegPeopleData_CSV))

            vec_temp = 0
            if 'SessionBodyVector.dict' in f and state_gov_nm in f:
                _SessionBodyVector = path.join(local_ds_path, f)
                with open(_SessionBodyVector,'rb') as fl:
                    vec_temp = pickle.load(fl)
                    years.extend(vec_temp['year'])
                    chambers.extend(vec_temp['chamber'])
                    vectors.extend(vec_temp['partisan_vector'])


    _bill_clusters = path.join(data_file_location, state_gov_nm + str(v) + str(c) + 'bill_clusters.df')

    with open(_cmltv_event_df,'rb') as f:
        leg_event_accumulated = pickle.load(f)

    with open(_bill_clusters,'rb') as f:
        leg_doc_clusters = pickle.load(f)

    leg_data = leg_data_raw

    LegSponsorDF['sponsors'] = pd.Categorical(LegSponsorDF['sponsors'],categories=LegSponsorDF['sponsors'].unique())

    LegSponsorDF = pd.get_dummies(LegSponsorDF, columns=['sponsors'])
    LegSponsorDF = LegSponsorDF.groupby(['bill_id']).sum()

    #create the session vector dictionary
    SessionBodyVectors = {'year' : years, 'chamber' : chambers, 'partisan_vector' : vectors}
    SessionBodyMakeup = pd.DataFrame(SessionBodyVectors)
    SessionBodyMakeup['year'] = SessionBodyMakeup['year'].astype('int16')
    SessionBodyMakeup['chamber'] = SessionBodyMakeup['chamber'].astype('str')
    ##########################################################################################
    #Clean up and combine the dataframes
    leg_doc_clusters['bill_id'] = leg_doc_clusters['bill_id'].astype('int64')
    leg_data['bill_id'] = leg_data['bill_id'].astype('int64')
    leg_data['time_t'] = leg_data['time_t'].astype('int8')
    leg_event_accumulated['time_t'] = leg_event_accumulated['time_t'].astype('int8')
    leg_data = leg_data.drop(columns=['event', 'next_event', 'previous_event', 'Unnamed: 0', 'primary_id','title','committee_introduced'])

    leg_data['bill_type'] = leg_data['bill_type'].astype('str')
    leg_data['proposed_chamber'] = leg_data['proposed_chamber'].astype('str')
    leg_data['primary_name'] = leg_data['primary_name'].astype('str')
    leg_data['primary_party'] = leg_data['primary_party'].astype('str')
    leg_data['chamber'] = leg_data['chamber'].astype('str')
    leg_data['chamber'] = leg_data['chamber'].fillna('None')
    leg_data['chamber'] = leg_data['chamber'].replace(to_replace='A', value='H')
    print(len(leg_data[leg_data['chamber'] == 'None']))
    leg_data['primary_name'] = leg_data['primary_name'].fillna('None')
    leg_data['primary_party'] = leg_data['primary_party'].fillna('N')

    #adjust the number of sponsors, based on the max value found in the field (for future iterations, just divide by the number in that particular chamber)
    max_sponsors = leg_data['number_sponsors'].max()
    leg_data['num_sponsors_adj'] = (leg_data['number_sponsors']*1.00)/max_sponsors

    #filtering out all types of legislation except bills (no resolutions, constitutional ammendments, etc.)
    leg_data = leg_data[leg_data['bill_type']=='B']

    print(len(leg_data))

    leg_data = pd.merge(leg_data, leg_doc_clusters, how='inner', on=['bill_id'])
    print(len(leg_data))

    leg_data = pd.merge(leg_data, leg_event_accumulated, how='inner', on=['bill_id','time_t'])
    print(len(leg_data))

    leg_data = pd.merge(leg_data, LegSponsorDF, how='inner', on=['bill_id'])
    print(len(leg_data))

    if state_gov_nm not in ['MA']: #some states don't have the data needed for a partisasn vector.  those states need manual creation of the vector files
        leg_data = pd.merge(leg_data, SessionBodyMakeup, how='inner', on=['year','chamber'])
    else:
        leg_data['partisan_vector'] = [.5] * len(leg_data)
    print(len(leg_data))

    try:
        leg_data = leg_data.drop(columns=['Unnamed: 0'])
    except:
        print('No additional Unnamed Column')
    _dataframe_export = path.join(data_file_location, state_gov_nm + str(v) + str(c) + '_dataset.df')


    with open(_dataframe_export, 'wb') as f:
        pickle.dump(leg_data, f)