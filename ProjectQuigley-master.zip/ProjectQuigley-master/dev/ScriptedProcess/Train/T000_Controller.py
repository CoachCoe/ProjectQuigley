#this script will handle the automated training of the models for eah state, using the saved parameters for each state
#load data, train models, and output models and files for each process
#will leverage azure machine learning for the bulk training

import sys
from os import path, environ
import T100_TrainEmbeddingModel
import T200_TrainClusterModel
import T300_CreateTrainingDataset
import T400_TrainModel
from multiprocessing import Process, freeze_support, active_children
from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core import Dataset, Workspace

state_list_location = sys.argv[1]
year_to_process = sys.argv[2]
script_file_location = sys.argv[3]
data_file_location = sys.argv[4]
model_file_location = sys.argv[5]
vector_size = sys.argv[6]
cluster_size = sys.argv[7]

state_list = ['NY','MA','US','IL','OH','PA']

sp = ServicePrincipalAuthentication(tenant_id="26abc6ef-f140-44d3-87ec-94ac09fd36d2", # tenantID
                                    service_principal_id="b7431496-79ec-4906-915d-de3ca0970716", # clientId
                                    service_principal_password=environ.get('MLQUIGSECRET')) # clientSecret

ws = Workspace.get(name="ml-quigley"
                , subscription_id='8d8bcbfe-86b4-42bb-a470-a8cf97c98d69'
                , resource_group='project-quigley'
                , auth=sp
                    )

if __name__ == '__main__':
	#Necessary for Windows
	freeze_support()

#run the embeddings, first
    for s in state_list:
        #if more thn one state is running the embeddings, hold up until one finishes
        if active_children() > 1 then:
            p1.join()
        
        p1 = Process(target=train_embeddings, args=(s, year_to_process, data_file_location, model_file_location, vector_size, 8, ws))
        p1.start()

#run the clustering
    for s in state_list:
        #if more than one state is running the clusters, hold up until one finishes
        if active_children() > 1 then:
            p1.join()
        
        p1 = Process(target=train_cluster, args=(s, year_to_process, data_file_location, model_file_location, vector_size, cluster_size))
        p1.start()

#run the clustering
    for s in state_list:
        #if more than one state is running the clusters, hold up until one finishes
        if active_children() > 4 then:
            p1.join()
        
        p1 = Process(target=create_training_dataset, args=(s, year_to_process, data_file_location, vector_size, cluster_size, ws))
        p1.start()
