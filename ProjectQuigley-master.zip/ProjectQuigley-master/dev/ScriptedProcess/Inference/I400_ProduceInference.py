import pickle
import numpy as np
import pandas as pd
from pprint import pprint
from time import time
import logging
import sys
import tensorflow as tf
from os import path
from os import listdir
from tensorflow import keras
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split
from tensorflow import feature_column
from tensorflow.keras.callbacks import TensorBoard
from azureml.core import Dataset, Workspace
import joblib
from tensorflow.keras.models import load_model

state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]
model_file_location = sys.argv[4]
vector_size = sys.argv[5]
cluster_size = sys.argv[6]

# A utility method to create a tf.data dataset from a Pandas Dataframe
#labels are derived from the "passed" column-------------------------------
def df_to_dataset(dataframe, shuffle=True, batch_size=32):
  dataframe = dataframe.copy()
  labels = dataframe.pop('passed')
  ds = tf.data.Dataset.from_tensor_slices((dict(dataframe), labels))
  if shuffle:
    ds = ds.shuffle(buffer_size=len(dataframe))
  ds = ds.batch(batch_size)
  return ds
#---------------------------------------------------------------------------

_dataset = path.join(data_file_location, state_gov_nm + year_to_process + str(vector_size) + str(cluster_size) + '_dataset.df')

with open(_dataset, 'rb') as f:
    leg_data = pickle.load(f)

inference_set = leg_data

#take only the latest event for inference
idx = inference_set.groupby(['bill_id'])['time_t'].transform(max) == inference_set['time_t']
inference_set = inference_set[idx]
print(len(inference_set))

batch_size = 512
inference_ds = df_to_dataset(inference_set, batch_size=batch_size)

loaded_model = load_model(
    model_file_location,
    custom_objects=None,
    compile=True
)

loaded_model.predict(inference_ds)