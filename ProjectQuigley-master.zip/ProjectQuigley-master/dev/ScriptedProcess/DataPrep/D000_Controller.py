#this script will control all of the data prep activities for the Quigley process
#this includes: running the necessary scripts, managing multi-threading, uploading the files to the azure datalake, and adjusting permissions to the files on the DL


import sys
from os import path, environ

## Required for Data Lake Storage Gen1 account management
from azure.mgmt.datalake.store import DataLakeStoreAccountManagementClient
from azure.mgmt.datalake.store.models import DataLakeStoreAccount

## Required for Data Lake Storage Gen1 filesystem management
from azure.datalake.store import core, lib, multithread

# Common Azure imports
import adal
from azure.mgmt.resource.resources import ResourceManagementClient
from azure.mgmt.resource.resources.models import ResourceGroup

## Use these as needed for your application
import logging, getpass, pprint, uuid, time

state_list_location = sys.argv[1]
script_file_location = sys.argv[2]
data_file_location = sys.argv[3]
azure_auth_location = sys.argv[4]

if __name__ == '__main__':

    #first, establish the azure connection for the azure storage so upload can be done to the data lake

    tenant = '26abc6ef-f140-44d3-87ec-94ac09fd36d2'
    RESOURCE = 'https://datalake.azure.net/'
    client_id = 'b7431496-79ec-4906-915d-de3ca0970716'
    client_secret = environ.get('MLQuigleySecret')

    adlCreds = lib.auth(tenant_id = tenant,
                    client_secret = client_secret,
                    client_id = client_id,
                    resource = RESOURCE)

    ## Declare variables
    #subscriptionId = '8d8bcbfe-86b4-42bb-a470-a8cf97c98d69'
    adlsAccountName = 'quigleydl'

    ## Create a filesystem client object
    adlsFileSystemClient = core.AzureDLFileSystem(adlCreds, store_name=adlsAccountName)

    #next, execute all of the scripts in the process
    #


    #Upload the files to azure data lake


    #Update the permissions for each file