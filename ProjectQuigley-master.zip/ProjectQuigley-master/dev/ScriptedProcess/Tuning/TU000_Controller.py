#this script will handle the automated tuning of each process.  The models will be run with various configurations and executed for each state.
#the final output of this will be a config file that will be used by the training process to train the models

import sys
from os import path, environ

## Required for Data Lake Storage Gen1 account management
from azure.mgmt.datalake.store import DataLakeStoreAccountManagementClient
from azure.mgmt.datalake.store.models import DataLakeStoreAccount

## Required for Data Lake Storage Gen1 filesystem management
from azure.datalake.store import core, lib, multithread

# Common Azure imports
import adal
from azure.mgmt.resource.resources import ResourceManagementClient
from azure.mgmt.resource.resources.models import ResourceGroup

## Use these as needed for your application
import logging, getpass, pprint, uuid, time

state_list_location = sys.argv[1]
script_file_location = sys.argv[2]
data_file_location = sys.argv[3]
azure_auth_location = sys.argv[4]

if __name__ == '__main__':

    #accept the 

    