import pickle
import numpy as np
import pandas as pd
from pprint import pprint
from time import time
import logging
import sys
import tensorflow as tf
from os import path
from tensorflow import keras
from tensorflow.keras import layers


state_gov_nm = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

print('running ', state_gov_nm)


#Import CSV file into pandas dataframe



#transform feature columns


#test/train split



#define NN



#run iterations