import pickle
import pandas as df
from os import path
import sys

state_list = sys.argv[1]
year_to_process = sys.argv[2]
data_file_location = sys.argv[3]

combined_text = []

state_list = state_list.split(',')

#state_list = ['AK','CA','HI','IL','NY','MA','MI','WI','OH','PA']

for s in state_list:
    print('Running:',s)
    with open(path.join(data_file_location, s + year_to_process + 'legtext.corpus'),'rb') as f:
        legtext = pickle.load(f)

    combined_text.extend(legtext)

with open(path.join(data_file_location, year_to_process + 'CombinedLegtext.corpus'),'wb') as f:
    pickle.dump(combined_text, f)