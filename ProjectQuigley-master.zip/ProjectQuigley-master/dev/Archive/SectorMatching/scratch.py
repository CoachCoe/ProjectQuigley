import pickle

with open('C:\\Users\\William Mitchell\\Documents\\QuigleyData\\WI2020SPsector.DF','rb') as f:
    SPsectorDF = pickle.load(f)

print(SPsectorDF.head())